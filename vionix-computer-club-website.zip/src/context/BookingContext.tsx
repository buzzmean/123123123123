import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import type { ZoneId } from "../data/content";

type BookingContextValue = {
  zoneId: ZoneId;
  setZoneId: (id: ZoneId) => void;
  duration: "h1" | "h3" | "h5";
  setDuration: (d: "h1" | "h3" | "h5") => void;
  goToBooking: (id?: ZoneId) => void;
};

const BookingContext = createContext<BookingContextValue | null>(null);

export function BookingProvider({ children }: { children: ReactNode }) {
  const [zoneId, setZoneId] = useState<ZoneId>("standard");
  const [duration, setDuration] = useState<"h1" | "h3" | "h5">("h1");

  const goToBooking = useCallback((id?: ZoneId) => {
    if (id) setZoneId(id);
    const el = document.getElementById("booking");
    if (el) {
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      el.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
      window.setTimeout(() => {
        document.getElementById("booking-name")?.focus();
      }, reduce ? 0 : 450);
    }
  }, []);

  const value = useMemo(
    () => ({ zoneId, setZoneId, duration, setDuration, goToBooking }),
    [zoneId, duration, goToBooking],
  );

  return <BookingContext.Provider value={value}>{children}</BookingContext.Provider>;
}

export function useBooking() {
  const ctx = useContext(BookingContext);
  if (!ctx) throw new Error("useBooking must be used within BookingProvider");
  return ctx;
}
