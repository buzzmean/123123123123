import { BookingProvider } from "./context/BookingContext";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { Hero } from "./sections/Hero";
import { About } from "./sections/About";
import { Zones } from "./sections/Zones";
import { Pricing } from "./sections/Pricing";
import { Equipment } from "./sections/Equipment";
import { Gallery } from "./sections/Gallery";
import { Playstation } from "./sections/Playstation";
import { Booking } from "./sections/Booking";
import { Contacts } from "./sections/Contacts";

export default function App() {
  return (
    <BookingProvider>
      <a
        href="#about"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[80] focus:bg-cream focus:px-4 focus:py-2 focus:text-night"
      >
        К содержанию
      </a>
      <div className="grain" aria-hidden="true" />
      <Header />
      <main>
        <Hero />
        <About />
        <Zones />
        <Pricing />
        <Equipment />
        <Gallery />
        <Playstation />
        <Booking />
        <Contacts />
      </main>
      <Footer />
    </BookingProvider>
  );
}
