import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { CLUB, NAV } from "../data/content";
import { useBooking } from "../context/BookingContext";
import { Logo } from "./Logo";
import { Button } from "./Button";
import { cn } from "../utils/cn";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const { goToBooking } = useBooking();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const ids = ["about", "zones", "prices", "equipment", "gallery", "ps5", "booking", "contacts"];
    const els = ids.map((id) => document.getElementById(id)).filter(Boolean) as HTMLElement[];
    if (!els.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(`#${visible.target.id}`);
      },
      { rootMargin: "-40% 0px -50% 0px", threshold: [0.1, 0.25, 0.5] },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled || open ? "border-b border-line bg-void/92 backdrop-blur-md" : "border-b border-transparent bg-transparent",
      )}
    >
      <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-5 md:px-8">
        <Logo />

        <nav className="hidden items-center gap-7 lg:flex" aria-label="Основная навигация">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className={cn(
                "nav-link text-[11px] font-medium tracking-[0.2em] uppercase text-sand transition-colors hover:text-cream",
                active === item.href && "is-active text-cream",
              )}
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Button
            className="hidden sm:inline-flex"
            onClick={() => {
              setOpen(false);
              goToBooking();
            }}
          >
            Бронь
          </Button>
          <button
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center text-cream lg:hidden"
            aria-label={open ? "Закрыть меню" : "Открыть меню"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      <div
        className={cn(
          "fixed inset-x-0 top-[72px] bottom-0 z-40 bg-void lg:hidden",
          open ? "flex" : "hidden",
        )}
      >
        <nav className="flex h-full w-full flex-col justify-between px-6 py-8" aria-label="Мобильная навигация">
          <div className="flex flex-col">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="border-b border-line py-4 font-display text-4xl text-cream"
              >
                {item.label}
              </a>
            ))}
          </div>
          <div className="flex flex-col gap-4 pb-4">
            <Button
              onClick={() => {
                setOpen(false);
                goToBooking();
              }}
            >
              Забронировать
            </Button>
            <a href={CLUB.phoneHref} className="text-center text-sm tracking-wide text-sand">
              {CLUB.phone}
            </a>
          </div>
        </nav>
      </div>
    </header>
  );
}
