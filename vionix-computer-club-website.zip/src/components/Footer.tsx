import { CLUB, NAV } from "../data/content";
import { Logo } from "./Logo";

export function Footer() {
  return (
    <footer className="border-t border-line bg-night">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-12 md:px-8">
        <div className="md:col-span-5">
          <Logo />
          <p className="mt-6 max-w-sm text-sm leading-relaxed text-sand">
            Компьютерный клуб в центре Ставрополя. 36 игровых мест, отдельные пространства DUO
            и зона PlayStation 5. Формат 16+.
          </p>
        </div>

        <div className="md:col-span-3">
          <p className="text-[11px] tracking-[0.22em] uppercase text-gold">Разделы</p>
          <ul className="mt-4 space-y-2">
            {NAV.map((item) => (
              <li key={item.href}>
                <a href={item.href} className="text-sm text-sand transition-colors hover:text-cream">
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div className="md:col-span-4">
          <p className="text-[11px] tracking-[0.22em] uppercase text-gold">Клуб</p>
          <ul className="mt-4 space-y-2 text-sm text-sand">
            <li>{CLUB.addressFull}</li>
            <li>
              <a href={CLUB.phoneHref} className="hover:text-cream">
                {CLUB.phone}
              </a>
            </li>
            <li>
              <a href={CLUB.emailHref} className="hover:text-cream">
                {CLUB.email}
              </a>
            </li>
            <li>{CLUB.hours}</li>
            <li>Формат {CLUB.age}</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-line">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-5 py-6 text-xs text-sand/80 md:flex-row md:items-center md:justify-between md:px-8">
          <p>© {new Date().getFullYear()} {CLUB.name}. {CLUB.legalName}</p>
          <p>ИНН {CLUB.inn}</p>
        </div>
      </div>
    </footer>
  );
}
