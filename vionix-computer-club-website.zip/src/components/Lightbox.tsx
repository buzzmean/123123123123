import { useEffect } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

type Item = { src: string; alt: string; caption: string };

type Props = {
  items: Item[];
  index: number | null;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
};

export function Lightbox({ items, index, onClose, onPrev, onNext }: Props) {
  const item = index === null ? null : items[index];

  useEffect(() => {
    if (index === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") onPrev();
      if (e.key === "ArrowRight") onNext();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [index, onClose, onPrev, onNext]);

  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center bg-void/92 px-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Просмотр изображения"
      onClick={onClose}
    >
      <button
        type="button"
        className="absolute right-5 top-5 text-cream"
        aria-label="Закрыть"
        onClick={onClose}
      >
        <X size={26} />
      </button>
      <button
        type="button"
        className="absolute left-3 top-1/2 -translate-y-1/2 p-3 text-cream md:left-6"
        aria-label="Предыдущее фото"
        onClick={(e) => {
          e.stopPropagation();
          onPrev();
        }}
      >
        <ChevronLeft size={32} />
      </button>
      <figure
        className="max-h-[86vh] max-w-5xl"
        onClick={(e) => e.stopPropagation()}
      >
        <img
          src={item.src}
          alt={item.alt}
          className="max-h-[78vh] w-full object-contain"
        />
        <figcaption className="mt-4 text-center text-sm text-sand">
          {item.caption}. Визуализация атмосферы, не фотография клуба VIONIX.
        </figcaption>
      </figure>
      <button
        type="button"
        className="absolute right-3 top-1/2 -translate-y-1/2 p-3 text-cream md:right-6"
        aria-label="Следующее фото"
        onClick={(e) => {
          e.stopPropagation();
          onNext();
        }}
      >
        <ChevronRight size={32} />
      </button>
    </div>
  );
}
