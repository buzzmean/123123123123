import { cn } from "../utils/cn";

export function Logo({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <a href="#top" className={cn("group inline-flex items-center gap-3", className)} aria-label="VIONIX — на главную">
      <svg
        width="28"
        height="28"
        viewBox="0 0 28 28"
        fill="none"
        aria-hidden="true"
        className="shrink-0 text-gold-2 transition-transform duration-500 group-hover:translate-y-px"
      >
        <path
          d="M5 5.5 L14 23 L23 5.5"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      <span
        className={cn(
          "tracking-[0.32em] text-[13px] font-semibold text-cream",
          compact ? "hidden sm:inline" : "inline",
        )}
      >
        VIONIX
      </span>
    </a>
  );
}
