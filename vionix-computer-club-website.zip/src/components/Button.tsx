import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "../utils/cn";

type Variant = "gold" | "ghost" | "line";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  children: ReactNode;
  href?: string;
  external?: boolean;
};

const styles: Record<Variant, string> = {
  gold: "gold-btn bg-cream text-night hover:bg-gold-2",
  ghost: "border border-line-strong text-cream hover:border-gold-2 hover:text-gold-2",
  line: "text-sand hover:text-cream",
};

export function Button({
  variant = "gold",
  className,
  children,
  href,
  external,
  type = "button",
  ...rest
}: Props) {
  const cls = cn(
    "inline-flex min-h-12 items-center justify-center gap-2 px-6 py-3 text-[12px] font-semibold tracking-[0.18em] uppercase transition-colors duration-300",
    styles[variant],
    className,
  );

  if (href) {
    return (
      <a
        href={href}
        className={cls}
        {...(external ? { target: "_blank", rel: "noreferrer noopener" } : undefined)}
      >
        {children}
      </a>
    );
  }

  return (
    <button type={type} className={cls} {...rest}>
      {children}
    </button>
  );
}
