export type ZoneId = "standard" | "arena" | "bootcamp" | "duo27" | "duo24";

export interface Zone {
  id: ZoneId;
  name: string;
  short: string;
  kicker: string;
  seats: number;
  description: string;
  image: string;
  imageAlt: string;
  prices: { h1: number; h3: number; h5: number };
  specs: { label: string; value: string }[];
  peripherals: string[];
}

export const NAV = [
  { href: "#about", label: "Клуб" },
  { href: "#zones", label: "Зоны" },
  { href: "#prices", label: "Цены" },
  { href: "#equipment", label: "Оборудование" },
  { href: "#gallery", label: "Галерея" },
  { href: "#ps5", label: "PlayStation 5" },
  { href: "#contacts", label: "Контакты" },
] as const;

export const CLUB = {
  name: "VIONIX",
  city: "Ставрополь",
  address: "ул. Ленина, 231/11",
  addressFull: "ул. Ленина, 231/11, Ставрополь",
  phone: "+7 994 311-11-55",
  phoneHref: "tel:+79943111155",
  email: "vionix2626@gmail.com",
  emailHref: "mailto:vionix2626@gmail.com",
  hours: "Ежедневно, круглосуточно",
  age: "16+",
  seats: 36,
  consoles: 1,
  floors: 2,
  site: "https://vionixclub.ru",
  langame:
    "https://langame.ru/799457480_computerniy_club_vionix_stavropol",
  mapEmbed:
    "https://www.openstreetmap.org/export/embed.html?bbox=41.9585%2C45.0365%2C41.9725%2C45.0425&layer=mapnik&marker=45.039483%2C41.965508",
  mapLink: "https://www.openstreetmap.org/?mlat=45.039483&mlon=41.965508#map=18/45.039483/41.965508",
  legalName: "ИП Косарев Иван Александрович",
  inn: "263514028109",
  lat: 45.039483,
  lng: 41.965508,
};

export const ZONES: Zone[] = [
  {
    id: "standard",
    name: "STANDARD",
    short: "Standard",
    kicker: "17 мест",
    seats: 17,
    description:
      "Базовая зона для ежедневной игры: актуальная сборка на RTX 5060, мониторы 240–300 Гц и спокойная посадка без лишней театральности.",
    image: "/images/zones/standard.jpg",
    imageAlt: "Визуализация зоны STANDARD: ряд игровых мест в тёмном зале с тёплым светом",
    prices: { h1: 180, h3: 430, h5: 680 },
    specs: [
      { label: "Процессор", value: "AMD Ryzen 5 7500F" },
      { label: "Видеокарта", value: "Gigabyte GeForce RTX 5060" },
      { label: "Память", value: "32 ГБ DDR4" },
      { label: "Монитор", value: "ViewSonic 23.8″ 240 Гц / AOC 27″ 300 Гц" },
      { label: "Кресло", value: "ZONE 51 Armada" },
      { label: "Сеть", value: "более 1 Гбит/с" },
    ],
    peripherals: [
      "Logitech PRO X2 RAPID",
      "Logitech PRO X2 SUPERSTRIKE",
      "Logitech PRO X3 LIGHTSPEED",
    ],
  },
  {
    id: "arena",
    name: "ARENA",
    short: "Arena 5×5",
    kicker: "10 мест · 5×5",
    seats: 10,
    description:
      "Командная зона 5×5: два ряда напротив друг друга, RTX 5070 Ti и мониторы 400 Гц — для игры составом, а не поодиночке в общем зале.",
    image: "/images/zones/arena.jpg",
    imageAlt: "Визуализация зоны ARENA: два ряда игровых станций друг напротив друга",
    prices: { h1: 230, h3: 550, h5: 850 },
    specs: [
      { label: "Процессор", value: "AMD Ryzen 7 7800X3D" },
      { label: "Видеокарта", value: "MSI GeForce RTX 5070 Ti" },
      { label: "Память", value: "32 ГБ DDR4" },
      { label: "Монитор", value: "ViewSonic 25″ 400 Гц" },
      { label: "Кресло", value: "ZONE 51 Cyberpunk" },
      { label: "Сеть", value: "более 1 Гбит/с" },
    ],
    peripherals: [
      "Logitech PRO X2 RAPID",
      "Logitech PRO X2 SUPERSTRIKE",
      "Logitech PRO X3 LIGHTSPEED",
    ],
  },
  {
    id: "bootcamp",
    name: "BOOTCAMP",
    short: "Bootcamp",
    kicker: "5 мест",
    seats: 5,
    description:
      "Более камерная зона на том же уровне железа, что и ARENA, с отдельной периферией. Для тех, кому нужна концентрация, а не общий ряд.",
    image: "/images/zones/bootcamp.jpg",
    imageAlt: "Визуализация зоны BOOTCAMP: изолированные игровые кабины",
    prices: { h1: 270, h3: 650, h5: 1050 },
    specs: [
      { label: "Процессор", value: "AMD Ryzen 7 7800X3D" },
      { label: "Видеокарта", value: "MSI GeForce RTX 5070 Ti" },
      { label: "Память", value: "32 ГБ DDR5" },
      { label: "Монитор", value: "MSI 24″ 300 Гц" },
      { label: "Кресло", value: "ZONE 51 Cyberpunk" },
      { label: "Сеть", value: "более 1 Гбит/с" },
    ],
    peripherals: ["Red Square ALUMIX"],
  },
  {
    id: "duo27",
    name: "DUO 27′",
    short: "Duo 27″",
    kicker: "2 места · 2K",
    seats: 2,
    description:
      "Приватная зона на двоих с 27-дюймовым 2K-монитором 320 Гц. Для спокойной сессии вдвоём — без общего зала и лишнего движения вокруг.",
    image: "/images/zones/duo27.jpg",
    imageAlt: "Визуализация приватной зоны DUO 27 с двумя игровыми местами",
    prices: { h1: 350, h3: 900, h5: 1350 },
    specs: [
      { label: "Процессор", value: "AMD Ryzen 7 7800X3D" },
      { label: "Видеокарта", value: "MSI GeForce RTX 5070 Ti" },
      { label: "Память", value: "32 ГБ DDR5" },
      { label: "Монитор", value: "27″ 2K 320 Гц" },
      { label: "Кресло", value: "ZONE 51 Imperial" },
      { label: "Сеть", value: "более 1 Гбит/с" },
    ],
    peripherals: ["Logitech PRO X2 SUPERSTRIKE"],
  },
  {
    id: "duo24",
    name: "DUO 24′",
    short: "Duo 24″",
    kicker: "2 места · 540 Гц",
    seats: 2,
    description:
      "Компактная Duo-зона с 24-дюймовым монитором 540 Гц. Тот же приватный формат, но с акцентом на герцовку и соревновательный отклик.",
    image: "/images/zones/duo24.jpg",
    imageAlt: "Визуализация приватной зоны DUO 24 с мониторами 24 дюйма",
    prices: { h1: 350, h3: 900, h5: 1350 },
    specs: [
      { label: "Процессор", value: "AMD Ryzen 7 7800X3D" },
      { label: "Видеокарта", value: "MSI GeForce RTX 5070 Ti" },
      { label: "Память", value: "32 ГБ DDR5" },
      { label: "Монитор", value: "Acer 24″ 540 Гц" },
      { label: "Кресло", value: "ZONE 51 Cyberpunk Limited Royal" },
      { label: "Сеть", value: "более 1 Гбит/с" },
    ],
    peripherals: [
      "Logitech PRO X2 RAPID",
      "Logitech PRO X2 SUPERSTRIKE",
      "Logitech PRO X3 LIGHTSPEED",
    ],
  },
];

export const PRICE_DURATIONS = [
  { id: "h1" as const, label: "1 час", hours: 1 },
  { id: "h3" as const, label: "3 часа", hours: 3 },
  { id: "h5" as const, label: "5 часов", hours: 5 },
];

export const EQUIPMENT = [
  {
    name: "Logitech PRO X2 RAPID",
    kind: "Клавиатура",
    zones: ["STANDARD", "ARENA", "DUO 24′"],
  },
  {
    name: "Logitech PRO X2 SUPERSTRIKE",
    kind: "Мышь",
    zones: ["STANDARD", "ARENA", "DUO 27′", "DUO 24′"],
  },
  {
    name: "Logitech PRO X3 LIGHTSPEED",
    kind: "Наушники",
    zones: ["STANDARD", "ARENA", "DUO 24′"],
  },
  {
    name: "Red Square ALUMIX",
    kind: "Клавиатура",
    zones: ["BOOTCAMP"],
  },
];

export const GALLERY = [
  {
    src: "/images/gallery/hall.jpg",
    alt: "Визуализация двухэтажного игрового пространства",
    caption: "Два уровня",
    span: "wide",
  },
  {
    src: "/images/hero.jpg",
    alt: "Визуализация основного зала с рядом игровых мест",
    caption: "Основной зал",
    span: "tall",
  },
  {
    src: "/images/zones/standard.jpg",
    alt: "Визуализация зоны STANDARD",
    caption: "Standard",
    span: "normal",
  },
  {
    src: "/images/zones/arena.jpg",
    alt: "Визуализация командной зоны ARENA",
    caption: "Arena",
    span: "normal",
  },
  {
    src: "/images/zones/bootcamp.jpg",
    alt: "Визуализация зоны BOOTCAMP",
    caption: "Bootcamp",
    span: "normal",
  },
  {
    src: "/images/gallery/desk.jpg",
    alt: "Крупный план игрового места: клавиатура, мышь и наушники",
    caption: "Место",
    span: "normal",
  },
  {
    src: "/images/zones/duo27.jpg",
    alt: "Визуализация приватной зоны DUO",
    caption: "Duo 27′",
    span: "normal",
  },
  {
    src: "/images/zones/duo24.jpg",
    alt: "Визуализация зоны DUO 24",
    caption: "Duo 24′",
    span: "normal",
  },
  {
    src: "/images/ps5.jpg",
    alt: "Визуализация зоны PlayStation 5",
    caption: "PlayStation 5",
    span: "wide",
  },
];

export const RULES = [
  "К посещению допускаются гости от 16 лет.",
  "Бережное отношение к оборудованию и имуществу клуба обязательно.",
  "Запрещены действия, которые мешают другим гостям.",
  "Администрация вправе отказать в обслуживании при нарушении правил.",
];

export function formatPrice(value: number) {
  return `${value.toLocaleString("ru-RU")} ₽`;
}

export function zoneById(id: string) {
  return ZONES.find((z) => z.id === id);
}
