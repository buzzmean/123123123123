import { ArrowUpRight } from "lucide-react";
import { Reveal } from "../components/Reveal";
import { Button } from "../components/Button";
import { ZONES, formatPrice, type Zone } from "../data/content";
import { useBooking } from "../context/BookingContext";
import { cn } from "../utils/cn";

const chooser = [
  { title: "Играю один", text: "STANDARD — если нужна спокойная сессия. BOOTCAMP — если важнее камерность и железо." },
  { title: "Командой", text: "ARENA — формат 5×5, два ряда напротив. Для состава, а не для случайных соседей." },
  { title: "Вдвоём", text: "DUO 27′ — 2K и больше экран. DUO 24′ — 540 Гц и более соревновательный отклик." },
  { title: "Консоль", text: "Отдельная зона PlayStation 5 — диван, телевизор, без компьютерного ряда." },
];

function ZoneSpecs({ zone }: { zone: Zone }) {
  return (
    <dl className="mt-6 grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
      {zone.specs.map((s) => (
        <div key={s.label} className="border-t border-line pt-3">
          <dt className="text-[10px] tracking-[0.18em] uppercase text-sand">{s.label}</dt>
          <dd className="mt-1 text-sm text-cream">{s.value}</dd>
        </div>
      ))}
    </dl>
  );
}

function ZoneActions({ zone }: { zone: Zone }) {
  const { goToBooking, setZoneId } = useBooking();
  return (
    <div className="mt-8 flex flex-wrap items-center gap-4">
      <p className="font-display text-3xl text-cream">
        {formatPrice(zone.prices.h1)}
        <span className="ml-2 font-sans text-xs tracking-[0.16em] uppercase text-sand">час</span>
      </p>
      <Button
        onClick={() => {
          setZoneId(zone.id);
          goToBooking(zone.id);
        }}
      >
        Забронировать
      </Button>
      <a href="#prices" className="text-[11px] tracking-[0.18em] uppercase text-sand hover:text-cream">
        Смотреть тарифы
      </a>
    </div>
  );
}

export function Zones() {
  const standard = ZONES[0];
  const arena = ZONES[1];
  const bootcamp = ZONES[2];
  const duos = ZONES.slice(3);

  return (
    <section id="zones" className="bg-void py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <p className="text-[11px] tracking-[0.28em] uppercase text-gold">Игровые зоны</p>
          <h2 className="font-display mt-4 max-w-2xl text-4xl leading-tight text-cream md:text-5xl">
            Пять форматов — от общего ряда до закрытого Duo
          </h2>
        </Reveal>

        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {chooser.map((item, i) => (
            <Reveal key={item.title} delay={i * 80}>
              <article className="h-full border border-line p-5">
                <p className="text-[11px] tracking-[0.2em] uppercase text-gold-2">{item.title}</p>
                <p className="mt-3 text-sm leading-relaxed text-sand">{item.text}</p>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-20">
          <article className="grid overflow-hidden border border-line lg:grid-cols-12">
            <div className="group relative min-h-[320px] lg:col-span-7 lg:min-h-[560px]">
              <img
                src={standard.image}
                alt={standard.imageAlt}
                className="img-zoom absolute inset-0 h-full w-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="flex flex-col justify-center bg-raise p-7 lg:col-span-5 lg:p-12">
              <p className="text-[11px] tracking-[0.24em] uppercase text-gold">
                01 · {standard.kicker}
              </p>
              <h3 className="font-display mt-3 text-4xl text-cream">{standard.name}</h3>
              <p className="mt-4 text-sm leading-relaxed text-sand">{standard.description}</p>
              <ZoneSpecs zone={standard} />
              <ZoneActions zone={standard} />
            </div>
          </article>
        </Reveal>

        <Reveal className="mt-6">
          <article className="grid overflow-hidden border border-line lg:grid-cols-12">
            <div className="flex flex-col justify-center bg-raise p-7 lg:col-span-5 lg:order-1 lg:p-12">
              <p className="text-[11px] tracking-[0.24em] uppercase text-gold">
                02 · {arena.kicker}
              </p>
              <h3 className="font-display mt-3 text-4xl text-cream">{arena.name}</h3>
              <p className="mt-4 text-sm leading-relaxed text-sand">{arena.description}</p>
              <ZoneSpecs zone={arena} />
              <ZoneActions zone={arena} />
            </div>
            <div className="group relative min-h-[320px] lg:col-span-7 lg:order-2 lg:min-h-[560px]">
              <img
                src={arena.image}
                alt={arena.imageAlt}
                className="img-zoom absolute inset-0 h-full w-full object-cover"
                loading="lazy"
              />
            </div>
          </article>
        </Reveal>

        <Reveal className="mt-6">
          <article className="relative min-h-[540px] overflow-hidden border border-line">
            <img
              src={bootcamp.image}
              alt={bootcamp.imageAlt}
              className="absolute inset-0 h-full w-full object-cover"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-void/92 via-void/70 to-void/20" />
            <div className="relative flex min-h-[540px] max-w-xl flex-col justify-end p-7 md:p-12">
              <p className="text-[11px] tracking-[0.24em] uppercase text-gold-2">
                03 · {bootcamp.kicker}
              </p>
              <h3 className="font-display mt-3 text-4xl text-cream md:text-5xl">{bootcamp.name}</h3>
              <p className="mt-4 text-sm leading-relaxed text-sand">{bootcamp.description}</p>
              <ZoneSpecs zone={bootcamp} />
              <ZoneActions zone={bootcamp} />
            </div>
          </article>
        </Reveal>

        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          {duos.map((zone, i) => (
            <Reveal key={zone.id} delay={i * 90}>
              <article className="group flex h-full flex-col overflow-hidden border border-line bg-raise">
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    src={zone.image}
                    alt={zone.imageAlt}
                    className="img-zoom h-full w-full object-cover"
                    loading="lazy"
                  />
                  <span className="absolute left-4 top-4 bg-void/70 px-3 py-1 text-[10px] tracking-[0.2em] uppercase text-gold-2 backdrop-blur-sm">
                    0{i + 4} · {zone.kicker}
                  </span>
                </div>
                <div className="flex flex-1 flex-col p-7">
                  <h3 className="font-display text-3xl text-cream">{zone.name}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-sand">{zone.description}</p>
                  <ZoneSpecs zone={zone} />
                  <div className="mt-auto">
                    <ZoneActions zone={zone} />
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-10">
          <a
            href="#ps5"
            className={cn(
              "flex items-center justify-between border border-line px-5 py-5 text-sand transition-colors hover:border-gold hover:text-cream",
            )}
          >
            <span className="text-sm">Нужна консоль, а не компьютер — откройте зону PlayStation 5</span>
            <ArrowUpRight size={18} />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
