import { EQUIPMENT } from "../data/content";
import { Reveal } from "../components/Reveal";

export function Equipment() {
  return (
    <section id="equipment" className="bg-void py-24 md:py-32">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 md:grid-cols-12 md:px-8">
        <div className="md:col-span-5">
          <Reveal>
            <p className="text-[11px] tracking-[0.28em] uppercase text-gold">Оборудование</p>
            <h2 className="font-display mt-4 text-4xl leading-tight text-cream md:text-5xl">
              Периферия, с которой играется место
            </h2>
            <p className="mt-5 text-sm leading-relaxed text-sand">
              Ниже — устройства, которые стоят в зонах клуба. Характеристики моделей не дополняем:
              указаны только названия и зоны, где они используются.
            </p>
          </Reveal>
          <Reveal delay={100} className="mt-8">
            <div className="overflow-hidden border border-line">
              <img
                src="/images/equipment.jpg"
                alt="Клавиатура, мышь и наушники на тёмной поверхности"
                className="h-full w-full object-cover"
                loading="lazy"
              />
            </div>
          </Reveal>
        </div>

        <div className="md:col-span-7">
          <ul className="divide-y divide-line border border-line">
            {EQUIPMENT.map((item, i) => (
              <Reveal key={item.name} delay={i * 70}>
                <li className="grid gap-4 bg-night p-6 sm:grid-cols-12 sm:items-center">
                  <div className="sm:col-span-7">
                    <p className="text-[11px] tracking-[0.2em] uppercase text-gold">{item.kind}</p>
                    <h3 className="mt-2 text-lg text-cream">{item.name}</h3>
                  </div>
                  <div className="flex flex-wrap gap-2 sm:col-span-5 sm:justify-end">
                    {item.zones.map((z) => (
                      <span
                        key={z}
                        className="border border-line px-2 py-1 text-[10px] tracking-[0.14em] uppercase text-sand"
                      >
                        {z}
                      </span>
                    ))}
                  </div>
                </li>
              </Reveal>
            ))}
          </ul>

          <Reveal className="mt-8">
            <div className="relative overflow-hidden border border-line">
              <img
                src="/images/gallery/desk.jpg"
                alt="Игровое место крупным планом"
                className="aspect-[16/8] w-full object-cover"
                loading="lazy"
              />
            </div>
            <p className="mt-4 text-xs leading-relaxed text-sand/80">
              Сборки ПК по зонам указаны в карточках STANDARD, ARENA, BOOTCAMP и DUO: процессор,
              видеокарта, монитор и кресло. Здесь — только периферия из исходных данных.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
