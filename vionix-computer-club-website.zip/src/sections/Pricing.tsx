import { PRICE_DURATIONS, ZONES, formatPrice } from "../data/content";
import { Reveal } from "../components/Reveal";
import { Button } from "../components/Button";
import { useBooking } from "../context/BookingContext";
import { cn } from "../utils/cn";

export function Pricing() {
  const { duration, setDuration, goToBooking, setZoneId, zoneId } = useBooking();
  const active = PRICE_DURATIONS.find((d) => d.id === duration) ?? PRICE_DURATIONS[0];

  return (
    <section id="prices" className="bg-night py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <Reveal>
            <p className="text-[11px] tracking-[0.28em] uppercase text-gold">Цены</p>
            <h2 className="font-display mt-4 text-4xl text-cream md:text-5xl">Прайс-лист</h2>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-sand">
              Выберите длительность — стоимость по зонам обновится сразу. DUO 27′ и DUO 24′ идут
              по одному тарифу. Дневные и ночные пакеты уточняются на стойке и в сервисе бронирования.
            </p>
          </Reveal>

          <Reveal delay={80}>
            <div
              className="inline-flex border border-line p-1"
              role="tablist"
              aria-label="Длительность сессии"
            >
              {PRICE_DURATIONS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  aria-selected={duration === item.id}
                  data-active={duration === item.id}
                  className="price-tab min-h-11 px-5 text-[11px] font-semibold tracking-[0.16em] uppercase text-sand transition-colors"
                  onClick={() => setDuration(item.id)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </Reveal>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-2 xl:grid-cols-5">
          {ZONES.map((zone, i) => {
            const price = zone.prices[duration];
            const selected = zoneId === zone.id;
            return (
              <Reveal key={zone.id} delay={i * 60}>
                <button
                  type="button"
                  onClick={() => setZoneId(zone.id)}
                  className={cn(
                    "flex h-full w-full flex-col border p-6 text-left transition-colors duration-300",
                    selected ? "border-gold-2 bg-raise" : "border-line bg-void hover:border-line-strong",
                  )}
                >
                  <p className="text-[11px] tracking-[0.2em] uppercase text-gold">{zone.kicker}</p>
                  <h3 className="mt-3 font-display text-2xl text-cream">{zone.name}</h3>
                  <p className="mt-8 font-display text-4xl text-cream">{formatPrice(price)}</p>
                  <p className="mt-1 text-[11px] tracking-[0.16em] uppercase text-sand">
                    за {active.label.toLowerCase()}
                  </p>
                  <p className="mt-6 text-xs text-sand">
                    {formatPrice(zone.prices.h1)} / час · {formatPrice(zone.prices.h3)} / 3 ч ·{" "}
                    {formatPrice(zone.prices.h5)} / 5 ч
                  </p>
                </button>
              </Reveal>
            );
          })}
        </div>

        <Reveal className="mt-8 flex flex-col items-start justify-between gap-4 border border-line bg-raise px-6 py-5 sm:flex-row sm:items-center">
          <p className="text-sm text-sand">
            Выбрано: <span className="text-cream">{ZONES.find((z) => z.id === zoneId)?.name}</span>
            {" · "}
            {active.label}
            {" · "}
            {formatPrice(ZONES.find((z) => z.id === zoneId)!.prices[duration])}
          </p>
          <Button onClick={() => goToBooking(zoneId)}>Перейти к заявке</Button>
        </Reveal>

        <Reveal className="mt-16 overflow-x-auto">
          <table className="w-full min-w-[640px] border-collapse text-left text-sm">
            <caption className="sr-only">Таблица цен по зонам и длительности</caption>
            <thead>
              <tr className="border-b border-line text-[11px] tracking-[0.18em] uppercase text-sand">
                <th className="py-4 pr-4 font-medium">Зона</th>
                <th className="py-4 pr-4 font-medium">1 час</th>
                <th className="py-4 pr-4 font-medium">3 часа</th>
                <th className="py-4 font-medium">5 часов</th>
              </tr>
            </thead>
            <tbody>
              {ZONES.map((zone) => (
                <tr key={zone.id} className="border-b border-line">
                  <th className="py-4 pr-4 font-medium text-cream">{zone.name}</th>
                  <td className="py-4 pr-4 text-sand">{formatPrice(zone.prices.h1)}</td>
                  <td className="py-4 pr-4 text-sand">{formatPrice(zone.prices.h3)}</td>
                  <td className="py-4 text-sand">{formatPrice(zone.prices.h5)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="mt-4 text-xs text-sand/80">
            DUO 27′ и DUO 24′ — единый тариф DUO. Актуальные пакеты на день и ночь смотрите при бронировании.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
