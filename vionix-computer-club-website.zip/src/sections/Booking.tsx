import { useMemo, useState, type FormEvent } from "react";
import { CLUB, PRICE_DURATIONS, ZONES, formatPrice } from "../data/content";
import { Reveal } from "../components/Reveal";
import { Button } from "../components/Button";
import { useBooking } from "../context/BookingContext";
import { cn } from "../utils/cn";

type Errors = Partial<Record<"name" | "phone" | "zone" | "date" | "time" | "duration", string>>;

function digitsPhone(value: string) {
  let d = value.replace(/\D/g, "");
  if (d.startsWith("8")) d = "7" + d.slice(1);
  if (!d.startsWith("7")) d = "7" + d;
  return d.slice(0, 11);
}

function maskPhone(value: string) {
  const d = digitsPhone(value);
  const p = d.slice(1);
  let r = "+7";
  if (p.length > 0) r += " (" + p.slice(0, 3);
  if (p.length >= 3) r += ")";
  if (p.length > 3) r += " " + p.slice(3, 6);
  if (p.length > 6) r += "-" + p.slice(6, 8);
  if (p.length > 8) r += "-" + p.slice(8, 10);
  return r;
}

function todayISO() {
  const t = new Date();
  const m = String(t.getMonth() + 1).padStart(2, "0");
  const d = String(t.getDate()).padStart(2, "0");
  return `${t.getFullYear()}-${m}-${d}`;
}

const TIMES = Array.from({ length: 24 }, (_, h) => `${String(h).padStart(2, "0")}:00`);

export function Booking() {
  const { zoneId, setZoneId, duration, setDuration } = useBooking();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("+7 ");
  const [date, setDate] = useState(todayISO());
  const [time, setTime] = useState("18:00");
  const [errors, setErrors] = useState<Errors>({});
  const [done, setDone] = useState(false);

  const zone = ZONES.find((z) => z.id === zoneId)!;
  const hours = PRICE_DURATIONS.find((d) => d.id === duration)!.hours;
  const price = zone.prices[duration];

  const summary = useMemo(
    () => `${zone.name} · ${hours} ч · ${formatPrice(price)}`,
    [zone, hours, price],
  );

  function validate() {
    const next: Errors = {};
    const trimmed = name.trim();
    if (trimmed.length < 2) next.name = "Укажите имя — минимум 2 символа";
    else if (!/^[A-Za-zА-Яа-яЁё\s-]+$/.test(trimmed)) next.name = "Используйте только буквы, пробел или дефис";

    if (digitsPhone(phone).length !== 11) next.phone = "Введите номер полностью: +7 (XXX) XXX-XX-XX";
    if (!zoneId) next.zone = "Выберите зону";
    if (!date) next.date = "Укажите дату";
    else if (date < todayISO()) next.date = "Дата не может быть в прошлом";
    if (!time) next.time = "Укажите время";
    if (!duration) next.duration = "Укажите длительность";
    return next;
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const next = validate();
    setErrors(next);
    if (Object.keys(next).length) return;
    setDone(true);
  }

  if (done) {
    return (
      <section id="booking" className="bg-night py-24 md:py-32">
        <div className="mx-auto max-w-3xl px-5 md:px-8">
          <p className="text-[11px] tracking-[0.28em] uppercase text-gold">Заявка</p>
          <h2 className="font-display mt-4 text-4xl text-cream">Черновик заявки собран</h2>
          <p className="mt-5 text-sm leading-relaxed text-sand">
            Это демонстрационный сценарий. Данные остались в браузере и не отправлены в клуб.
            Чтобы забронировать место по-настоящему, используйте Langame — рабочий сервис бронирования VIONIX.
          </p>
          <div className="mt-8 border border-line bg-raise p-6 text-sm text-cream">
            <p>{name.trim()}</p>
            <p className="mt-2 text-sand">{phone}</p>
            <p className="mt-2 text-sand">
              {summary}
              <br />
              {date} · {time}
            </p>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button href={CLUB.langame} external>
              Открыть бронь в Langame
            </Button>
            <Button variant="ghost" onClick={() => setDone(false)}>
              Изменить заявку
            </Button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="booking" className="bg-night py-24 md:py-32">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 md:grid-cols-12 md:px-8">
        <div className="md:col-span-5">
          <Reveal>
            <p className="text-[11px] tracking-[0.28em] uppercase text-gold">Бронирование</p>
            <h2 className="font-display mt-4 text-4xl leading-tight text-cream md:text-5xl">
              Заявка на посещение
            </h2>
            <p className="mt-5 text-sm leading-relaxed text-sand">
              Форма собирает черновик локально и ничего не бронирует. Реальная бронь мест VIONIX
              идёт через Langame.
            </p>
            <div className="mt-8 border border-line p-6">
              <p className="text-[11px] tracking-[0.2em] uppercase text-gold">Рабочая бронь</p>
              <p className="mt-3 text-sm text-sand">
                Откроется в новой вкладке на странице клуба в Langame.
              </p>
              <Button className="mt-5" href={CLUB.langame} external>
                Перейти в Langame
              </Button>
            </div>
            <p className="mt-6 text-sm text-sand">
              Или позвоните{" "}
              <a href={CLUB.phoneHref} className="text-cream underline-offset-4 hover:underline">
                {CLUB.phone}
              </a>
            </p>
          </Reveal>
        </div>

        <Reveal className="md:col-span-7" delay={80}>
          <form onSubmit={onSubmit} noValidate className="border border-line bg-raise p-6 md:p-8">
            <div className="grid gap-5 sm:grid-cols-2">
              <label className="block sm:col-span-1">
                <span className="mb-2 block text-[11px] tracking-[0.16em] uppercase text-sand">Имя</span>
                <input
                  id="booking-name"
                  className={cn("field", errors.name && "field-error")}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                  placeholder="Как к вам обращаться"
                />
                {errors.name && <span className="mt-1 block text-xs text-[#d9a39a]">{errors.name}</span>}
              </label>

              <label className="block">
                <span className="mb-2 block text-[11px] tracking-[0.16em] uppercase text-sand">Телефон</span>
                <input
                  className={cn("field", errors.phone && "field-error")}
                  value={phone}
                  onChange={(e) => setPhone(maskPhone(e.target.value))}
                  inputMode="tel"
                  autoComplete="tel"
                  placeholder="+7 (___) ___-__-__"
                />
                {errors.phone && <span className="mt-1 block text-xs text-[#d9a39a]">{errors.phone}</span>}
              </label>

              <label className="block sm:col-span-2">
                <span className="mb-2 block text-[11px] tracking-[0.16em] uppercase text-sand">Зона</span>
                <select
                  className={cn("field", errors.zone && "field-error")}
                  value={zoneId}
                  onChange={(e) => setZoneId(e.target.value as typeof zoneId)}
                >
                  {ZONES.map((z) => (
                    <option key={z.id} value={z.id}>
                      {z.name} — от {formatPrice(z.prices.h1)}/час
                    </option>
                  ))}
                </select>
              </label>

              <label className="block">
                <span className="mb-2 block text-[11px] tracking-[0.16em] uppercase text-sand">Дата</span>
                <input
                  type="date"
                  min={todayISO()}
                  className={cn("field", errors.date && "field-error")}
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                />
                {errors.date && <span className="mt-1 block text-xs text-[#d9a39a]">{errors.date}</span>}
              </label>

              <label className="block">
                <span className="mb-2 block text-[11px] tracking-[0.16em] uppercase text-sand">Время</span>
                <select
                  className={cn("field", errors.time && "field-error")}
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                >
                  {TIMES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </label>

              <fieldset className="sm:col-span-2">
                <legend className="mb-2 text-[11px] tracking-[0.16em] uppercase text-sand">
                  Продолжительность
                </legend>
                <div className="grid grid-cols-3 gap-2">
                  {PRICE_DURATIONS.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setDuration(item.id)}
                      className={cn(
                        "min-h-12 border text-[11px] tracking-[0.14em] uppercase transition-colors",
                        duration === item.id
                          ? "border-gold-2 bg-cream text-night"
                          : "border-line text-sand hover:border-line-strong",
                      )}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </fieldset>
            </div>

            <div className="mt-6 flex flex-col gap-4 border-t border-line pt-5 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm text-sand">
                К оплате по прайсу: <span className="text-cream">{summary}</span>
              </p>
              <Button type="submit">Собрать заявку</Button>
            </div>
            <p className="mt-4 text-xs text-sand/70">
              Нажимая кнопку, вы не бронируете место и не отправляете данные на сервер клуба.
            </p>
          </form>
        </Reveal>
      </div>
    </section>
  );
}
