import { Clock3, Mail, MapPin, Phone } from "lucide-react";
import { CLUB, RULES } from "../data/content";
import { Reveal } from "../components/Reveal";

export function Contacts() {
  return (
    <section id="contacts" className="bg-void py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <p className="text-[11px] tracking-[0.28em] uppercase text-gold">Контакты</p>
          <h2 className="font-display mt-4 text-4xl text-cream md:text-5xl">Как добраться</h2>
        </Reveal>

        <div className="mt-12 grid gap-6 lg:grid-cols-12">
          <Reveal className="lg:col-span-5">
            <ul className="space-y-6">
              <li className="flex gap-4">
                <MapPin className="mt-1 shrink-0 text-gold" size={18} />
                <div>
                  <p className="text-[11px] tracking-[0.18em] uppercase text-sand">Адрес</p>
                  <p className="mt-1 text-cream">{CLUB.addressFull}</p>
                </div>
              </li>
              <li className="flex gap-4">
                <Phone className="mt-1 shrink-0 text-gold" size={18} />
                <div>
                  <p className="text-[11px] tracking-[0.18em] uppercase text-sand">Телефон</p>
                  <a href={CLUB.phoneHref} className="mt-1 block text-cream hover:text-gold-2">
                    {CLUB.phone}
                  </a>
                </div>
              </li>
              <li className="flex gap-4">
                <Mail className="mt-1 shrink-0 text-gold" size={18} />
                <div>
                  <p className="text-[11px] tracking-[0.18em] uppercase text-sand">Почта</p>
                  <a href={CLUB.emailHref} className="mt-1 block text-cream hover:text-gold-2">
                    {CLUB.email}
                  </a>
                </div>
              </li>
              <li className="flex gap-4">
                <Clock3 className="mt-1 shrink-0 text-gold" size={18} />
                <div>
                  <p className="text-[11px] tracking-[0.18em] uppercase text-sand">Режим</p>
                  <p className="mt-1 text-cream">{CLUB.hours}</p>
                  <p className="mt-1 text-sm text-sand">Формат {CLUB.age}</p>
                </div>
              </li>
            </ul>

            <div className="mt-10 border-t border-line pt-8">
              <p className="text-[11px] tracking-[0.18em] uppercase text-gold">Правила посещения</p>
              <ul className="mt-4 space-y-2 text-sm text-sand">
                {RULES.map((rule) => (
                  <li key={rule}>{rule}</li>
                ))}
              </ul>
            </div>
          </Reveal>

          <Reveal className="lg:col-span-7" delay={80}>
            <div className="overflow-hidden border border-line">
              <iframe
                title="Карта: VIONIX, ул. Ленина, 231/11, Ставрополь"
                src={CLUB.mapEmbed}
                className="h-[380px] w-full grayscale contrast-125 md:h-[480px]"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            <a
              href={CLUB.mapLink}
              target="_blank"
              rel="noreferrer noopener"
              className="mt-3 inline-block text-xs tracking-[0.14em] uppercase text-sand hover:text-cream"
            >
              Открыть карту отдельно
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
