import { ArrowDown } from "lucide-react";
import { CLUB } from "../data/content";
import { Button } from "../components/Button";
import { useBooking } from "../context/BookingContext";

export function Hero() {
  const { goToBooking } = useBooking();

  return (
    <section id="top" className="relative min-h-svh overflow-hidden">
      <img
        src="/images/hero.jpg"
        alt="Игровой зал с рядом компьютеров в тёплом тёмном интерьере"
        className="absolute inset-0 h-full w-full object-cover"
        fetchPriority="high"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-void/92 via-void/55 to-void/20" />
      <div className="absolute inset-0 bg-gradient-to-t from-void via-transparent to-void/45" />

      <div className="relative mx-auto flex min-h-svh max-w-7xl flex-col justify-end px-5 pb-10 pt-28 md:px-8 md:pb-14">
        <div className="max-w-3xl">
          <p className="text-[11px] font-medium tracking-[0.28em] uppercase text-gold-2">
            {CLUB.city} · {CLUB.address} · {CLUB.age}
          </p>
          <h1 className="font-display mt-5 text-7xl leading-[0.85] tracking-tight text-cream sm:text-8xl md:text-[7.5rem] lg:text-[8.5rem]">
            VIONIX
          </h1>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-sand sm:text-lg">
            Премиальный компьютерный клуб в центре города. 36 игровых мест, отдельные пространства
            DUO и зона PlayStation 5. Формат 16+, работа без перерывов.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button href="#zones">Выбрать зону</Button>
            <Button variant="ghost" onClick={() => goToBooking()}>
              Оставить заявку
            </Button>
          </div>
        </div>

        <div className="mt-14 grid grid-cols-2 gap-px overflow-hidden border border-line bg-line sm:grid-cols-4">
          {[
            { k: "36", v: "игровых мест" },
            { k: "5", v: "категорий зон" },
            { k: "540", v: "Гц на Duo 24" },
            { k: "24/7", v: "без выходных" },
          ].map((item) => (
            <div key={item.v} className="bg-void/70 px-4 py-4 backdrop-blur-sm sm:px-6">
              <p className="font-display text-3xl text-cream">{item.k}</p>
              <p className="mt-1 text-[11px] tracking-[0.16em] uppercase text-sand">{item.v}</p>
            </div>
          ))}
        </div>

        <a
          href="#about"
          className="mt-8 hidden items-center gap-2 text-[11px] tracking-[0.2em] uppercase text-sand transition-colors hover:text-cream md:inline-flex"
        >
          <ArrowDown size={14} />
          Смотреть дальше
        </a>
      </div>
    </section>
  );
}
