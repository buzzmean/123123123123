import { Reveal } from "../components/Reveal";
import { CLUB } from "../data/content";

const facts = [
  {
    title: "Два этажа",
    text: "Единственный двухэтажный компьютерный клуб в Ставрополе — больше пространства и отделённости, чем в обычном ряду компьютеров.",
  },
  {
    title: "Центр города",
    text: "ул. Ленина, 231/11. Удобно заехать после учёбы или работы, без долгой дороги через весь город.",
  },
  {
    title: "RTX 5060 / 5070 Ti",
    text: "Актуальные игровые конфигурации: от комфортной базы до топовых сборок с Ryzen 7 7800X3D.",
  },
  {
    title: "До 540 Гц",
    text: "В Duo 24 — мониторы 540 Гц. В остальных зонах — 240, 300 и 400 Гц в зависимости от категории.",
  },
  {
    title: "Формат 16+",
    text: "Возрастное ограничение держит более спокойную аудиторию и другой общий уровень посещения.",
  },
  {
    title: "Круглосуточно",
    text: "Клуб работает ежедневно, без выходных. Дневные и ночные визиты — в одном режиме.",
  },
];

export function About() {
  return (
    <section id="about" className="relative bg-night py-24 md:py-32">
      <div className="mx-auto grid max-w-7xl gap-16 px-5 md:grid-cols-12 md:px-8">
        <div className="md:col-span-5">
          <Reveal>
            <p className="text-[11px] tracking-[0.28em] uppercase text-gold">О клубе</p>
            <h2 className="font-display mt-4 text-4xl leading-tight text-cream md:text-5xl">
              Клуб, а не интернет-кафе
            </h2>
            <p className="mt-6 text-base leading-relaxed text-sand">
              VIONIX собран как игровое пространство: разные категории мест, отдельные DUO,
              консольная зона и посадка, в которой можно провести несколько часов без ощущения
              случайного зала.
            </p>
          </Reveal>

          <Reveal delay={120}>
            <div className="mt-12 flex items-end gap-4">
              <span className="font-display text-[7.5rem] leading-none text-cream">{CLUB.seats}</span>
              <span className="mb-4 max-w-[8rem] text-[11px] leading-snug tracking-[0.18em] uppercase text-sand">
                компьютеров
                <br />и {CLUB.consoles} консоль PS5
              </span>
            </div>
          </Reveal>
        </div>

        <div className="md:col-span-7">
          <div className="grid gap-px bg-line sm:grid-cols-2">
            {facts.map((fact, i) => (
              <Reveal key={fact.title} delay={i * 70}>
                <article className="h-full bg-night p-6 md:p-8">
                  <p className="text-[11px] tracking-[0.2em] uppercase text-gold-2">0{i + 1}</p>
                  <h3 className="mt-4 font-medium text-cream">{fact.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-sand">{fact.text}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
