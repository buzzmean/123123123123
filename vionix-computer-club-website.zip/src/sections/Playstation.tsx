import { CLUB } from "../data/content";
import { Reveal } from "../components/Reveal";
import { Button } from "../components/Button";
import { useBooking } from "../context/BookingContext";

export function Playstation() {
  const { goToBooking } = useBooking();

  return (
    <section id="ps5" className="bg-void py-24 md:py-32">
      <div className="mx-auto grid max-w-7xl overflow-hidden lg:grid-cols-2">
        <Reveal className="relative min-h-[380px]">
          <img
            src="/images/ps5.jpg"
            alt="Визуализация зоны PlayStation 5: диван, телевизор и консоль"
            className="absolute inset-0 h-full w-full object-cover"
            loading="lazy"
          />
        </Reveal>
        <div className="flex flex-col justify-center bg-raise px-6 py-12 md:px-12 lg:px-16">
          <Reveal>
            <p className="text-[11px] tracking-[0.28em] uppercase text-gold">Консольная зона</p>
            <h2 className="font-display mt-4 text-4xl text-cream md:text-5xl">PlayStation 5</h2>
            <p className="mt-5 max-w-md text-sm leading-relaxed text-sand">
              В клубе одна консоль PlayStation 5 — отдельное пространство для компании, а не место
              в общем компьютерном ряду. Телевизор, посадка на диване, консольный формат.
            </p>
            <ul className="mt-8 space-y-3 text-sm text-cream">
              <li className="flex gap-3">
                <span className="text-gold">01</span>
                Одна консоль PS5
              </li>
              <li className="flex gap-3">
                <span className="text-gold">02</span>
                Формат для компании и спокойной сессии
              </li>
              <li className="flex gap-3">
                <span className="text-gold">03</span>
                Без компьютерного ряда и герцовки мониторов
              </li>
            </ul>
            <p className="mt-8 text-xs leading-relaxed text-sand/80">
              Стоимость консольной зоны на этой странице не публикуем: в исходных данных для PS5
              отдельный тариф не задан. Наличие места и условия — на стойке, по телефону или в Langame.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button onClick={() => goToBooking()}>Оставить заявку</Button>
              <Button variant="ghost" href={CLUB.langame} external>
                Бронь в Langame
              </Button>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
