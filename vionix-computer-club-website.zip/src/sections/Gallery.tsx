import { useState } from "react";
import { GALLERY } from "../data/content";
import { Reveal } from "../components/Reveal";
import { Lightbox } from "../components/Lightbox";
import { cn } from "../utils/cn";

const layout = [
  "col-span-2 md:col-span-8 min-h-[240px] md:min-h-[460px]",
  "col-span-2 md:col-span-4 min-h-[240px] md:min-h-[460px]",
  "col-span-1 md:col-span-3 min-h-[200px] md:min-h-[260px]",
  "col-span-1 md:col-span-3 min-h-[200px] md:min-h-[260px]",
  "col-span-1 md:col-span-3 min-h-[200px] md:min-h-[260px]",
  "col-span-1 md:col-span-3 min-h-[200px] md:min-h-[260px]",
  "col-span-1 md:col-span-6 min-h-[200px] md:min-h-[320px]",
  "col-span-1 md:col-span-6 min-h-[200px] md:min-h-[320px]",
  "col-span-2 md:col-span-12 min-h-[220px] md:min-h-[380px]",
];

export function Gallery() {
  const [index, setIndex] = useState<number | null>(null);

  return (
    <section id="gallery" className="bg-night py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <p className="text-[11px] tracking-[0.28em] uppercase text-gold">Галерея</p>
          <h2 className="font-display mt-4 text-4xl text-cream md:text-5xl">Атмосфера пространства</h2>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-sand">
            Тематические визуализации в эстетике клуба, а не съёмка интерьера VIONIX. Нажмите на кадр,
            чтобы открыть его крупнее.
          </p>
        </Reveal>

        <div className="mt-12 grid grid-cols-2 gap-3 md:grid-cols-12 md:gap-4">
          {GALLERY.map((item, i) => (
            <Reveal key={item.src + item.caption} delay={(i % 4) * 50} className={cn("relative h-full", layout[i])}>
              <button
                type="button"
                onClick={() => setIndex(i)}
                className="group relative block h-full w-full overflow-hidden"
                aria-label={`Открыть: ${item.caption}`}
              >
                <img
                  src={item.src}
                  alt={item.alt}
                  className={cn("img-zoom absolute inset-0 h-full w-full object-cover")}
                  loading="lazy"
                />
                <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-void/85 to-transparent px-4 py-3 text-left text-[11px] tracking-[0.18em] uppercase text-cream opacity-90 transition-opacity duration-300 md:opacity-0 md:group-hover:opacity-100">
                  {item.caption}
                </span>
              </button>
            </Reveal>
          ))}
        </div>
      </div>

      <Lightbox
        items={GALLERY}
        index={index}
        onClose={() => setIndex(null)}
        onPrev={() => setIndex((i) => (i === null ? i : (i + GALLERY.length - 1) % GALLERY.length))}
        onNext={() => setIndex((i) => (i === null ? i : (i + 1) % GALLERY.length))}
      />
    </section>
  );
}
