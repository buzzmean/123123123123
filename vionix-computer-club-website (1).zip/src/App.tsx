import { useCallback, useRef, useState } from "react";
import { Booking, type BookingPreset } from "@/components/Booking";
import { Contacts } from "@/components/Contacts";
import { Equipment } from "@/components/Equipment";
import { Footer } from "@/components/Footer";
import { Gallery } from "@/components/Gallery";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { Intro } from "@/components/Intro";
import { PlayStation } from "@/components/PlayStation";
import { Pricing } from "@/components/Pricing";
import { Zones } from "@/components/Zones";
import type { BookingZoneId, DurationKey } from "@/data/site";

export default function App() {
  const [bookingPreset, setBookingPreset] = useState<BookingPreset | null>(null);
  const presetCounter = useRef(0);

  const handleBook = useCallback((zone?: BookingZoneId, duration?: DurationKey) => {
    if (zone) {
      presetCounter.current += 1;
      setBookingPreset({
        zone,
        duration: duration ?? "1",
        nonce: presetCounter.current,
      });
    }
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.requestAnimationFrame(() => {
      document.getElementById("booking")?.scrollIntoView({
        behavior: prefersReducedMotion ? "auto" : "smooth",
        block: "start",
      });
    });
  }, []);

  return (
    <div className="grain relative min-h-screen overflow-x-clip bg-coal text-cream">
      <a
        href="#main"
        className="sr-only z-[110] bg-gold px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-ink focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Перейти к содержанию
      </a>

      <Header />

      <main id="main">
        <Hero />
        <Intro />
        <Zones onBook={handleBook} />
        <Pricing onBook={handleBook} />
        <Equipment />
        <Gallery />
        <PlayStation onBook={handleBook} />
        <Booking preset={bookingPreset} />
        <Contacts />
      </main>

      <Footer />
    </div>
  );
}
