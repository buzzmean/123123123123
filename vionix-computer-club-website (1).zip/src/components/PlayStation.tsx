import { images, type BookingZoneId, type DurationKey } from "@/data/site";
import { ArrowUpRight, btnGold, btnOutline, InfoIcon, Reveal } from "@/components/ui";

const facts = [
  { label: "Консоль", value: "PlayStation 5" },
  { label: "Формат", value: "Отдельная зона" },
  { label: "Компания", value: "Одному или компанией" },
];

export function PlayStation({
  onBook,
}: {
  onBook: (zone: BookingZoneId, duration?: DurationKey) => void;
}) {
  return (
    <section id="ps5" className="relative overflow-hidden border-b border-cream/10 bg-coal py-24 lg:py-32">
      <div
        className="pointer-events-none absolute -right-10 top-8 select-none text-[clamp(5rem,18vw,16rem)] font-extralight leading-none tracking-[-0.04em] text-cream/[0.025] lg:top-12"
        aria-hidden="true"
      >
        PS5
      </div>

      <div className="shell relative">
        <div className="grid gap-10 lg:grid-cols-12 lg:items-center lg:gap-14">
          <Reveal className="lg:col-span-5">
            <p className="eyebrow">
              <span className="text-gold-deep">06</span>
              <span className="h-px w-6 bg-cream/25" aria-hidden="true" />
              Консольная зона
            </p>

            <h2 className="display mt-6 text-[clamp(2.5rem,5vw,4.6rem)] text-cream">
              PlayStation 5
              <br />
              <span className="italic-accent text-gold">в своём ритме.</span>
            </h2>

            <p className="mt-6 max-w-lg text-[14px] leading-[1.85] text-cream/65">
              В VIONIX предусмотрена отдельная PlayStation 5-зона — самостоятельный формат
              отдыха внутри клуба. Здесь можно играть одному или провести время компанией, не
              занимая компьютерное место.
            </p>

            <dl className="mt-8 grid grid-cols-1 border-t border-cream/15 sm:grid-cols-3">
              {facts.map((fact) => (
                <div
                  key={fact.label}
                  className="border-b border-cream/10 py-4 sm:border-b-0 sm:border-r sm:pr-4 sm:last:border-r-0 sm:pl-4 sm:first:pl-0"
                >
                  <dt className="text-[9px] uppercase tracking-[0.16em] text-stone">
                    {fact.label}
                  </dt>
                  <dd className="mt-2 text-[13px] font-medium leading-snug text-cream">
                    {fact.value}
                  </dd>
                </div>
              ))}
            </dl>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <button type="button" onClick={() => onBook("ps5")} className={btnGold}>
                Забронировать PlayStation 5
                <ArrowUpRight className="arrow-shift" />
              </button>
              <a href="#contacts" className={btnOutline}>
                Связаться с клубом
              </a>
            </div>

            <div className="mt-6 flex items-start gap-3 border-t border-cream/10 pt-5">
              <InfoIcon className="mt-0.5 shrink-0 text-gold" />
              <p className="max-w-md text-[11px] leading-[1.75] text-stone">
                Стоимость, количество мест и детали консольной зоны уточняйте у администратора
                клуба: в опубликованных данных эти характеристики не указаны.
              </p>
            </div>
          </Reveal>

          <Reveal delay={120} className="lg:col-span-7">
            <figure className="group relative">
              <div
                className="absolute -left-3 -top-3 h-24 w-24 border-l border-t border-gold/45 transition-all duration-700 group-hover:-left-4 group-hover:-top-4"
                aria-hidden="true"
              />
              <div className="relative overflow-hidden bg-bark">
                <img
                  src={images.ps5}
                  alt="Иллюстрация контроллера PlayStation 5 на консоли"
                  loading="lazy"
                  className="cine aspect-[4/3] w-full object-cover transition-transform duration-[1.5s] ease-out group-hover:scale-[1.03] sm:aspect-[16/11]"
                />
                <div
                  className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/5 to-transparent"
                  aria-hidden="true"
                />
                <div className="absolute inset-x-5 bottom-5 flex items-end justify-between gap-6 sm:inset-x-7 sm:bottom-7">
                  <div>
                    <span className="block text-[9px] uppercase tracking-[0.2em] text-gold">
                      Console zone
                    </span>
                    <figcaption className="mt-2 text-[1.35rem] font-light text-cream sm:text-[1.8rem]">
                      Отдельное пространство VIONIX
                    </figcaption>
                  </div>
                  <span className="hidden shrink-0 border border-cream/20 bg-coal/40 px-3 py-1.5 text-[9px] uppercase tracking-[0.16em] text-cream/70 backdrop-blur-md sm:block">
                    PlayStation 5
                  </span>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between gap-4">
                <span className="text-[9px] uppercase tracking-[0.16em] text-stone">
                  Иллюстративное изображение
                </span>
                <span className="h-px flex-1 bg-cream/10" aria-hidden="true" />
                <span className="text-[9px] uppercase tracking-[0.16em] text-stone">
                  VIONIX / Stavropol
                </span>
              </div>
            </figure>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
