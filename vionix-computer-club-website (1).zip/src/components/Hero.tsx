import { images, formatPrice, priceTable } from "@/data/site";
import { ArrowRight, ArrowUpRight, btnGold, btnOutline, MapPinIcon, Reveal } from "@/components/ui";

const facts = [
  { value: "36", label: "игровых компьютеров" },
  { value: "05", label: "форматов игровых зон" },
  { value: "PS5", label: "отдельная консольная зона" },
  { value: "DUO", label: "отдельные пространства для двоих" },
];

export function Hero() {
  return (
    <section id="top" className="relative isolate min-h-[100svh] overflow-hidden bg-coal">
      <div className="absolute inset-0" aria-hidden="true">
        <img
          src={images.hero}
          alt=""
          fetchPriority="high"
          className="cine h-full w-full object-cover object-[64%_center]"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-coal via-coal/90 to-coal/25" />
        <div className="absolute inset-0 bg-gradient-to-t from-coal via-coal/15 to-coal/75" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_78%_32%,rgba(201,177,139,0.13),transparent_38%)]" />
      </div>

      <div className="shell relative flex min-h-[100svh] flex-col justify-end pb-8 pt-28 lg:pb-10 lg:pt-32">
        <div className="grid flex-1 items-end gap-10 py-10 lg:grid-cols-12 lg:gap-8 lg:py-14">
          <div className="lg:col-span-8">
            <Reveal>
              <p className="eyebrow text-sand">
                <MapPinIcon className="h-3.5 w-3.5 text-gold" />
                Ставрополь · компьютерный клуб
              </p>
            </Reveal>

            <Reveal delay={100}>
              <h1 className="display mt-7 text-[clamp(2.25rem,8.2vw,7.5rem)] sm:mt-8">
                <span className="block text-cream">Играть</span>
                <span className="italic-accent mt-1 block text-gold sm:mt-2">
                  по&#8209;настоящему<span className="text-cream">.</span>
                </span>
              </h1>
            </Reveal>

            <Reveal delay={200}>
              <p className="mt-7 max-w-[34rem] text-[14px] leading-[1.8] text-cream/70 sm:text-[15px] lg:mt-9">
                36 игровых компьютеров и пять форматов посадки — от STANDARD до отдельных
                пространств DUO. Периферия Logitech PRO, собственная зона PlayStation 5 и внимание
                к деталям, из которых складывается атмосфера.
              </p>
            </Reveal>

            <Reveal delay={300}>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center lg:mt-10">
                <a href="#zones" className={btnGold}>
                  Выбрать игровую зону
                  <ArrowUpRight className="arrow-shift" />
                </a>
                <a href="#booking" className={btnOutline}>
                  Забронировать визит
                  <ArrowRight className="arrow-shift" />
                </a>
              </div>
            </Reveal>
          </div>

          <Reveal delay={400} className="hidden lg:col-span-4 lg:block">
            <div className="ml-auto w-full max-w-[20rem] border border-cream/15 bg-coal/45 p-6 backdrop-blur-xl">
              <div className="flex items-center justify-between gap-4 border-b border-cream/10 pb-4">
                <span className="text-[10px] uppercase tracking-[0.2em] text-sand">
                  Игровая категория
                </span>
                <span className="h-1.5 w-1.5 rounded-full bg-gold" aria-hidden="true" />
              </div>
              <div className="flex items-baseline justify-between gap-4 pt-5">
                <span className="text-[1.7rem] font-light tracking-[0.12em] text-cream">ARENA</span>
                <span className="text-[11px] uppercase tracking-[0.12em] text-stone">02 / 05</span>
              </div>
              <p className="mt-2 text-[13px] leading-relaxed text-sand">
                Полная конфигурация Logitech PRO
              </p>
              <div className="mt-5 flex items-end justify-between border-t border-cream/10 pt-4">
                <div>
                  <span className="text-[10px] uppercase tracking-[0.18em] text-stone">1 час</span>
                  <p className="mt-1 text-[1.4rem] font-light text-cream">
                    {formatPrice(priceTable.arena.prices["1"])} ₽
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase tracking-[0.18em] text-stone">3 часа</span>
                  <p className="mt-1 text-[1.4rem] font-light text-cream">
                    {formatPrice(priceTable.arena.prices["3"])} ₽
                  </p>
                </div>
              </div>
              <a
                href="#pricing"
                className="group mt-5 flex min-h-11 items-center justify-between gap-4 border-t border-cream/10 pt-4 text-[10px] uppercase tracking-[0.18em] text-gold transition-colors hover:text-cream"
              >
                Все категории и цены
                <ArrowRight className="arrow-line" />
              </a>
            </div>
          </Reveal>
        </div>

        <Reveal delay={500}>
          <div className="grid grid-cols-2 gap-x-6 gap-y-6 border-t border-cream/15 pt-6 lg:grid-cols-4 lg:gap-8 lg:pt-7">
            {facts.map((fact) => (
              <div key={fact.label} className="flex items-start gap-3 sm:gap-4">
                <span className="min-w-[3.4rem] text-[1.6rem] font-light leading-none tracking-[-0.02em] text-gold sm:text-[1.9rem]">
                  {fact.value}
                </span>
                <span className="max-w-[9rem] text-[10px] leading-[1.55] tracking-[0.08em] text-cream/55 uppercase sm:text-[11px]">
                  {fact.label}
                </span>
              </div>
            ))}
          </div>
        </Reveal>

        <div className="mt-5 flex items-center justify-between gap-6">
          <a
            href="#intro"
            className="group inline-flex items-center gap-3 text-[9px] uppercase tracking-[0.24em] text-cream/45 transition-colors hover:text-gold"
          >
            <span className="relative block h-8 w-px overflow-hidden bg-cream/20">
              <span className="scroll-cue absolute inset-0 bg-gold" />
            </span>
            Листайте
          </a>
          <span className="hidden text-[9px] uppercase tracking-[0.18em] text-cream/30 sm:block">
            Изображения — визуальные референсы пространства
          </span>
        </div>
      </div>
    </section>
  );
}
