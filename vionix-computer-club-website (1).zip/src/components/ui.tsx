import {
  useEffect,
  useRef,
  useState,
  type ReactNode,
  type KeyboardEvent as ReactKeyboardEvent,
} from "react";
import { createPortal } from "react-dom";
import { cn } from "@/utils/cn";

export const btnBase =
  "group inline-flex min-h-12 items-center justify-center gap-3 px-6 py-3.5 text-[11px] font-semibold uppercase tracking-[0.18em] transition-all duration-500";

export const btnGold = cn(btnBase, "bg-gold text-ink hover:bg-cream");
export const btnOutline = cn(
  btnBase,
  "border border-cream/25 text-cream hover:border-gold hover:text-gold",
);
export const btnDark = cn(
  btnBase,
  "border border-ink/15 bg-ink/[0.04] text-ink hover:border-ink/40 hover:bg-ink hover:text-cream",
);

export const fieldClass =
  "w-full min-h-12 border border-cream/15 bg-coal/60 px-4 py-3 text-[15px] text-cream placeholder:text-stone/70 transition-colors duration-300 hover:border-cream/25 focus:border-gold focus:outline-none";

export const labelClass =
  "mb-2.5 flex items-center justify-between gap-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-sand";

export function Logo({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <a
      href="#top"
      aria-label="VIONIX — к началу страницы"
      className={cn("group inline-flex items-center gap-3 text-cream", className)}
    >
      <svg
        viewBox="0 0 34 34"
        aria-hidden="true"
        className="h-8 w-8 shrink-0 text-cream/70 transition-colors duration-500 group-hover:text-gold"
        fill="none"
      >
        <rect x="0.5" y="0.5" width="33" height="33" stroke="currentColor" strokeOpacity="0.4" />
        <path d="M8.5 9.5 17 25l8.5-15.5" stroke="currentColor" strokeWidth="1.2" />
        <path d="M17 9.5V19" stroke="#c9b18b" strokeWidth="1.2" />
        <circle cx="17" cy="28.5" r="1.3" fill="#c9b18b" />
      </svg>
      <span
        className={cn(
          "font-light leading-none tracking-[0.32em]",
          compact ? "text-lg" : "text-[1.3rem]",
        )}
      >
        VIONIX
      </span>
    </a>
  );
}

export function ArrowUpRight({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 16 16"
      aria-hidden="true"
      className={cn("h-4 w-4 shrink-0", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M4 12 12 4M5 4h7v7" />
    </svg>
  );
}

export function ArrowRight({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 18 12"
      aria-hidden="true"
      className={cn("h-3 w-4 shrink-0", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M0 6h16M11.5 1 17 6l-5.5 5" />
    </svg>
  );
}

export function ArrowLeft({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 18 12"
      aria-hidden="true"
      className={cn("h-3 w-4 shrink-0", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M18 6H2M6.5 1 1 6l5.5 5" />
    </svg>
  );
}

export function CloseIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 20 20"
      aria-hidden="true"
      className={cn("h-5 w-5", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
    >
      <path d="m4 4 12 12M16 4 4 16" />
    </svg>
  );
}

export function MenuIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 16"
      aria-hidden="true"
      className={cn("h-4 w-6", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
    >
      <path d="M0 1h24M0 8h24M8 15h16" />
    </svg>
  );
}

export function MapPinIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 16 18"
      aria-hidden="true"
      className={cn("h-[18px] w-4", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M14.5 7.5c0 4.2-6.5 9-6.5 9s-6.5-4.8-6.5-9a6.5 6.5 0 1 1 13 0Z" />
      <circle cx="8" cy="7.4" r="2.2" />
    </svg>
  );
}

export function PlusIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 20 20"
      aria-hidden="true"
      className={cn("h-5 w-5", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.2"
    >
      <path d="M10 2v16M2 10h16" />
    </svg>
  );
}

export function CopyIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 20 20"
      aria-hidden="true"
      className={cn("h-4 w-4", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect x="6.5" y="6.5" width="11" height="11" />
      <path d="M13.5 6.5v-4h-11v11h4" />
    </svg>
  );
}

export function CheckIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 20 20"
      aria-hidden="true"
      className={cn("h-4 w-4", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m3 10.5 4.5 4.5L17 5" />
    </svg>
  );
}

export function InfoIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 20 20"
      aria-hidden="true"
      className={cn("h-4 w-4", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
    >
      <circle cx="10" cy="10" r="8" />
      <path d="M10 9v5M10 6.2v.2" />
    </svg>
  );
}

export function ClockIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 20 20"
      aria-hidden="true"
      className={cn("h-4 w-4", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="10" cy="10" r="8" />
      <path d="M10 5.5V10l3 2" />
    </svg>
  );
}

export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setVisible(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -6% 0px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={cn("reveal", visible && "is-in", className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

export function SectionHead({
  index,
  kicker,
  title,
  description,
  className,
  tone = "dark",
}: {
  index: string;
  kicker: string;
  title: ReactNode;
  description?: ReactNode;
  className?: string;
  tone?: "dark" | "light";
}) {
  return (
    <div className={cn("grid gap-8 lg:grid-cols-12 lg:gap-12", className)}>
      <div className="lg:col-span-8">
        <p className={cn("eyebrow", tone === "light" && "text-ink/55")}>
          <span className="text-gold-deep">{index}</span>
          <span className="h-px w-6 bg-current opacity-30" aria-hidden="true" />
          {kicker}
        </p>
        <h2
          className={cn(
            "display mt-6 text-[clamp(2.6rem,5.6vw,5.25rem)]",
            tone === "light" ? "text-ink" : "text-cream",
          )}
        >
          {title}
        </h2>
      </div>
      {description ? (
        <div
          className={cn(
            "max-w-sm text-[14px] leading-[1.8] lg:col-span-4 lg:justify-self-end lg:pb-2",
            tone === "light" ? "text-ink/65" : "text-sand",
          )}
        >
          {description}
        </div>
      ) : null}
    </div>
  );
}

export function Dialog({
  open,
  onClose,
  labelledBy,
  children,
  className,
  dark = false,
}: {
  open: boolean;
  onClose: () => void;
  labelledBy: string;
  children: ReactNode;
  className?: string;
  dark?: boolean;
}) {
  const panelRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (!open) return;
    const previousFocus = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const frame = window.requestAnimationFrame(() => closeRef.current?.focus());

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onCloseRef.current();
        return;
      }
      if (event.key !== "Tab" || !panelRef.current) return;
      const focusable = Array.from(
        panelRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      ).filter((element) => element.offsetParent !== null);
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => {
      window.cancelAnimationFrame(frame);
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus?.();
    };
  }, [open]);

  if (!open) return null;

  return createPortal(
    <div className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto p-4 sm:p-6">
      <div
        className="fixed inset-0 bg-ink/90 backdrop-blur-[6px]"
        onClick={() => onCloseRef.current()}
        aria-hidden="true"
      />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={labelledBy}
        className={cn(
          "fade-up relative z-10 my-auto max-h-[92svh] w-full overflow-y-auto border border-cream/15 shadow-[0_30px_120px_rgba(0,0,0,0.55)]",
          dark ? "bg-coal text-cream" : "bg-bark text-cream",
          className,
        )}
      >
        <button
          ref={closeRef}
          type="button"
          onClick={() => onCloseRef.current()}
          aria-label="Закрыть окно"
          className="absolute right-3 top-3 z-20 flex h-11 w-11 items-center justify-center border border-cream/15 bg-coal/70 text-cream backdrop-blur-md transition-colors hover:border-gold hover:text-gold"
        >
          <CloseIcon />
        </button>
        {children}
      </div>
    </div>,
    document.body,
  );
}

export function handleImageKey(event: ReactKeyboardEvent, action: () => void) {
  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    action();
  }
}
