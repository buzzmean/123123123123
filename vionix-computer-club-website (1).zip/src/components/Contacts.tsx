import { contactPlaceholders } from "@/data/site";
import {
  ArrowUpRight,
  btnGold,
  btnOutline,
  ClockIcon,
  InfoIcon,
  MapPinIcon,
  Reveal,
  SectionHead,
} from "@/components/ui";

const contactRows = [
  {
    label: "Адрес",
    value: contactPlaceholders.address,
    icon: <MapPinIcon className="h-4 w-4" />,
  },
  {
    label: "Телефон",
    value: contactPlaceholders.phone,
    icon: (
      <svg
        viewBox="0 0 18 18"
        aria-hidden="true"
        className="h-4 w-4"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M6 2.5 3 3.5c-.8.3-1.2 1.1-1 1.9 1.3 5.6 5 9.3 10.6 10.6.8.2 1.6-.2 1.9-1l1-3-4-2-1.5 2c-2.3-1-4-2.7-5-5l2-1.5-1-3Z" />
      </svg>
    ),
  },
  {
    label: "Режим работы",
    value: contactPlaceholders.hours,
    icon: <ClockIcon />,
  },
  {
    label: "Социальные сети",
    value: contactPlaceholders.social,
    icon: (
      <svg
        viewBox="0 0 18 18"
        aria-hidden="true"
        className="h-4 w-4"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="4" cy="9" r="2.2" />
        <circle cx="14" cy="4" r="2.2" />
        <circle cx="14" cy="14" r="2.2" />
        <path d="m6 8 6-3M6 10l6 3" />
      </svg>
    ),
  },
  {
    label: "Официальный сайт",
    value: contactPlaceholders.officialSite,
    icon: (
      <svg
        viewBox="0 0 18 18"
        aria-hidden="true"
        className="h-4 w-4"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="9" cy="9" r="7.5" />
        <path d="M1.5 9h15M9 1.5c2 2 3 4.5 3 7.5s-1 5.5-3 7.5c-2-2-3-4.5-3-7.5s1-5.5 3-7.5Z" />
      </svg>
    ),
  },
];

export function Contacts() {
  return (
    <section id="contacts" className="relative overflow-hidden border-b border-cream/10 bg-bark py-24 lg:py-32">
      <div className="shell">
        <Reveal>
          <SectionHead
            index="08"
            kicker="Контакты"
            title={
              <>
                Найти VIONIX
                <br />
                <span className="italic-accent text-gold">в Ставрополе.</span>
              </>
            }
            description={
              <p>
                Клуб находится в Ставрополе. Точный адрес, телефон и режим работы отмечены в этой
                версии как редактируемые заглушки — их необходимо заменить перед публикацией.
              </p>
            }
          />
        </Reveal>

        <div className="mt-12 grid gap-4 lg:mt-16 lg:grid-cols-12 lg:gap-5">
          <Reveal className="lg:col-span-5">
            <div className="flex h-full flex-col border border-cream/15 bg-coal/50 p-5 sm:p-7">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-cream/10 pb-4">
                <h3 className="text-[10px] font-semibold uppercase tracking-[0.18em] text-cream">
                  Контактные данные
                </h3>
                <span className="border border-gold/25 px-2.5 py-1.5 text-[8px] uppercase tracking-[0.14em] text-gold">
                  Черновик для публикации
                </span>
              </div>

              <dl className="flex-1">
                {contactRows.map((row) => (
                  <div
                    key={row.label}
                    className="flex items-start gap-4 border-b border-cream/10 py-4"
                  >
                    <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center border border-cream/10 text-gold-deep">
                      {row.icon}
                    </span>
                    <div className="min-w-0">
                      <dt className="text-[9px] uppercase tracking-[0.16em] text-stone">
                        {row.label}
                      </dt>
                      <dd className="mt-1.5 text-[13px] leading-relaxed text-cream/80">
                        {row.label === "Официальный сайт" ? (
                          <a
                            href="https://vionixclub.ru"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="underline-link inline-flex items-center gap-2 text-gold transition-colors hover:text-cream"
                          >
                            {row.value}
                            <ArrowUpRight className="h-3 w-3" />
                          </a>
                        ) : (
                          row.value
                        )}
                      </dd>
                    </div>
                  </div>
                ))}
              </dl>

              <div className="mt-5 flex items-start gap-3 text-[10px] leading-[1.7] text-stone">
                <InfoIcon className="mt-0.5 shrink-0 text-gold" />
                <p>
                  Точные контактные данные и карта будут добавлены перед публикацией. До этого
                  актуальную информацию уточняйте на официальном сайте клуба.
                </p>
              </div>

              <a href="#booking" className={`${btnGold} mt-5 w-full justify-between`}>
                Забронировать визит
                <ArrowUpRight className="arrow-shift" />
              </a>
            </div>
          </Reveal>

          <Reveal delay={120} className="lg:col-span-7">
            <div className="relative flex h-full min-h-[24rem] flex-col overflow-hidden border border-cream/15 bg-coal/40">
              <div className="fine-grid absolute inset-0 opacity-60" aria-hidden="true" />
              <div
                className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(201,177,139,0.1),transparent_55%)]"
                aria-hidden="true"
              />
              <svg
                className="absolute inset-0 h-full w-full text-gold/25"
                viewBox="0 0 800 560"
                fill="none"
                preserveAspectRatio="xMidYMid slice"
                aria-hidden="true"
              >
                <path d="M-20 400C120 360 210 300 290 210S510 90 820 120" stroke="currentColor" strokeWidth="1.2" />
                <path d="M-20 300C90 290 200 250 300 160S520 30 820 60" stroke="currentColor" strokeWidth="0.8" />
                <path d="M120 580C190 450 280 400 380 360S600 320 830 380" stroke="currentColor" strokeWidth="1.2" />
                <path d="M80 20C140 150 260 210 380 230s280-40 460-10" stroke="currentColor" strokeWidth="0.8" />
                <path d="M620 -20C560 120 540 260 610 400s140 140 230 130" stroke="currentColor" strokeWidth="0.8" />
              </svg>

              <div className="relative flex flex-1 flex-col items-center justify-center px-6 py-14 text-center">
                <span className="relative flex h-20 w-20 items-center justify-center">
                  <span className="absolute inset-0 animate-ping rounded-full border border-gold/20 [animation-duration:3.5s]" aria-hidden="true" />
                  <span className="absolute inset-3 rounded-full border border-gold/30" aria-hidden="true" />
                  <span className="flex h-10 w-10 items-center justify-center rounded-full border border-gold/50 bg-coal/70 text-gold backdrop-blur-md">
                    <MapPinIcon />
                  </span>
                </span>
                <span className="mt-6 text-[9px] uppercase tracking-[0.2em] text-gold">
                  Ставрополь · Россия
                </span>
                <p className="mt-2 max-w-sm text-[15px] leading-relaxed text-cream">
                  Место для карты клуба
                </p>
                <p className="mt-2 max-w-sm text-[11px] leading-[1.7] text-stone">
                  Точный адрес появится после подтверждения. Сейчас доступен только город клуба.
                </p>
                <a
                  href="https://yandex.ru/maps/26/stavropol/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-5 inline-flex min-h-11 items-center gap-2 border border-cream/20 px-4 text-[9px] font-semibold uppercase tracking-[0.14em] text-cream/75 transition-colors hover:border-gold hover:text-gold"
                >
                  Ставрополь на карте
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </a>
              </div>

              <div className="relative flex flex-wrap items-center justify-between gap-3 border-t border-cream/10 px-5 py-4 text-[9px] uppercase tracking-[0.14em] text-stone">
                <span>Точка на карте — после публикации</span>
                <span>VIONIX / 26 region</span>
              </div>
            </div>
          </Reveal>
        </div>

        <Reveal>
          <div className="mt-4 flex flex-col gap-4 border border-cream/10 bg-coal/30 p-5 sm:flex-row sm:items-center sm:justify-between">
            <p className="max-w-2xl text-[11px] leading-[1.75] text-sand">
              Для реального бронирования и уточнения деталей используйте официальные каналы
              связи клуба. Демонстрационная форма на этой странице не отправляет заявки.
            </p>
            <a
              href="https://vionixclub.ru"
              target="_blank"
              rel="noopener noreferrer"
              className={`${btnOutline} w-full shrink-0 sm:w-auto`}
            >
              vionixclub.ru
              <ArrowUpRight className="arrow-shift" />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
