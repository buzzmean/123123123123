import { images } from "@/data/site";
import { Reveal } from "@/components/ui";

const principles = [
  {
    index: "01",
    title: "Техника PRO-уровня",
    text: "Периферия Logitech PRO на игровых местах STANDARD, ARENA и в пространствах DUO 24'. Клавиатура Red Square ALUMIX — в BOOTCAMP.",
  },
  {
    index: "02",
    title: "Пять форматов посадки",
    text: "STANDARD, ARENA, BOOTCAMP, DUO 27' и DUO 24'. Можно прийти одному, с другом или собраться компанией.",
  },
  {
    index: "03",
    title: "Отдельные пространства",
    text: "Форматы DUO и консольная зона PlayStation 5 позволяют провести время в своём ритме, не подстраиваясь под общий зал.",
  },
];

const marqueeItems = ["Standard", "Arena", "Bootcamp", "Duo 27'", "Duo 24'", "PlayStation 5"];

export function Intro() {
  return (
    <section id="intro" className="relative overflow-hidden border-t border-cream/10 bg-coal py-24 lg:py-36">
      <div className="shell">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-8">
          <Reveal className="lg:col-span-4">
            <p className="eyebrow">
              <span className="text-gold-deep">01</span>
              <span className="h-px w-6 bg-cream/25" aria-hidden="true" />
              Пространство
            </p>
            <div className="mt-8 hidden h-px w-20 bg-gold/50 lg:block" aria-hidden="true" />
            <p className="mt-6 max-w-xs text-[13px] leading-[1.85] text-sand lg:mt-10">
              VIONIX — компьютерный клуб в Ставрополе. 36 игровых компьютеров, отдельная зона
              PlayStation 5 и несколько форматов игровых мест.
            </p>
          </Reveal>

          <Reveal delay={120} className="lg:col-span-8">
            <h2 className="display text-[clamp(2rem,4.4vw,4.1rem)] text-cream">
              Место, где техника,
              <br className="hidden sm:block" /> свет и тишина{" "}
              <span className="italic-accent text-gold">работают на игру.</span>
            </h2>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-10 border-t border-cream/10 pt-8 lg:mt-20 lg:grid-cols-12 lg:gap-14 lg:pt-12">
          <Reveal className="lg:col-span-5">
            <figure className="group relative overflow-hidden bg-bark-2">
              <img
                src={images.lounge}
                alt="Иллюстрация лаунж-пространства с мягким тёплым освещением"
                loading="lazy"
                className="cine aspect-[4/3] w-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-[1.03] lg:aspect-[5/6]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-transparent to-transparent" aria-hidden="true" />
              <figcaption className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-6 p-5">
                <span className="max-w-[12rem] text-[11px] uppercase leading-[1.7] tracking-[0.14em] text-cream/80">
                  Атмосфера
                  <br />
                  пространства
                </span>
                <span className="text-[9px] uppercase tracking-[0.16em] text-cream/40">
                  Visual reference
                </span>
              </figcaption>
            </figure>
          </Reveal>

          <div className="lg:col-span-7">
            <Reveal>
              <p className="max-w-2xl text-[15px] leading-[1.9] text-cream/70">
                Мы собрали клуб вокруг одной идеи: ничто не должно отвлекать от игры.
                Современное оборудование, продуманная посадка и сдержанный интерьер — чтобы
                сессия была такой, какой вы её задумали.
              </p>
            </Reveal>

            <div className="mt-8 border-t border-cream/10">
              {principles.map((item, index) => (
                <Reveal key={item.index} delay={index * 90}>
                  <div className="group grid gap-3 border-b border-cream/10 py-6 sm:grid-cols-[3rem_1fr] sm:gap-6 lg:py-7">
                    <span className="text-[10px] tabular-nums tracking-[0.16em] text-gold-deep transition-colors group-hover:text-gold">
                      {item.index}
                    </span>
                    <div>
                      <h3 className="text-[15px] font-medium tracking-[0.01em] text-cream">
                        {item.title}
                      </h3>
                      <p className="mt-2 max-w-xl text-[13px] leading-[1.8] text-sand">{item.text}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="marquee mt-20 overflow-hidden border-y border-cream/10 py-6 lg:mt-28 lg:py-8" aria-hidden="true">
        <div className="marquee-track items-center">
          {[0, 1].map((copy) => (
            <div key={copy} className="flex shrink-0 items-center">
              {marqueeItems.map((item) => (
                <span key={`${copy}-${item}`} className="flex items-center">
                  <span className="whitespace-nowrap px-7 text-[clamp(1.6rem,3.6vw,3.2rem)] font-extralight uppercase tracking-[0.08em] text-cream/35 lg:px-12">
                    {item}
                  </span>
                  <span className="h-1 w-1 rotate-45 bg-gold/70" />
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
