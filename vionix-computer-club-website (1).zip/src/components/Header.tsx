import { useEffect, useRef, useState } from "react";
import { navigation } from "@/data/site";
import { cn } from "@/utils/cn";
import {
  ArrowUpRight,
  btnGold,
  CloseIcon,
  Logo,
  MapPinIcon,
  MenuIcon,
} from "@/components/ui";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState<string>("");
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 24);
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const sections = navigation
      .map((item) => document.getElementById(item.id))
      .filter((section): section is HTMLElement => Boolean(section));
    if (sections.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: "-42% 0px -52% 0px", threshold: 0 },
    );
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const frame = window.requestAnimationFrame(() => closeButtonRef.current?.focus());
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("keydown", onKeyDown);
    return () => {
      window.cancelAnimationFrame(frame);
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKeyDown);
      menuButtonRef.current?.focus();
    };
  }, [menuOpen]);

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          scrolled
            ? "border-b border-cream/10 bg-coal/90 backdrop-blur-xl"
            : "border-b border-transparent bg-gradient-to-b from-ink/65 via-ink/20 to-transparent",
        )}
      >
        <div className="shell flex h-[4.5rem] items-center justify-between gap-6 lg:h-24">
          <Logo />

          <nav aria-label="Основная навигация" className="hidden lg:block">
            <ul className="flex items-center gap-6 xl:gap-8">
              {navigation.map((item) => (
                <li key={item.id}>
                  <a
                    href={item.href}
                    aria-current={active === item.id ? "true" : undefined}
                    className={cn(
                      "group relative inline-flex min-h-11 items-center text-[12px] font-medium tracking-[0.04em] transition-colors duration-300",
                      active === item.id ? "text-gold" : "text-cream/75 hover:text-cream",
                    )}
                  >
                    {item.label}
                    <span
                      aria-hidden="true"
                      className={cn(
                        "absolute bottom-2.5 left-0 h-px bg-gold transition-all duration-500",
                        active === item.id ? "w-full" : "w-0 group-hover:w-full",
                      )}
                    />
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="flex items-center gap-3 sm:gap-5">
            <span className="hidden items-center gap-2 text-[11px] uppercase tracking-[0.16em] text-sand xl:flex">
              <MapPinIcon className="text-gold-deep" />
              Ставрополь
            </span>
            <a href="#booking" className={cn(btnGold, "min-h-11 px-4 py-2.5 text-[10px] sm:px-5")}>
              <span className="hidden sm:inline">Забронировать</span>
              <span className="sm:hidden">Бронь</span>
              <ArrowUpRight className="arrow-shift h-3.5 w-3.5" />
            </a>
            <button
              ref={menuButtonRef}
              type="button"
              onClick={() => setMenuOpen(true)}
              aria-expanded={menuOpen}
              aria-controls="mobile-menu"
              aria-label="Открыть меню"
              className="flex h-11 w-11 items-center justify-center border border-cream/20 text-cream transition-colors hover:border-gold hover:text-gold lg:hidden"
            >
              <MenuIcon />
            </button>
          </div>
        </div>
      </header>

      {menuOpen ? (
        <div
          id="mobile-menu"
          role="dialog"
          aria-modal="true"
          aria-label="Меню сайта"
          className="fixed inset-0 z-[90] flex flex-col overflow-y-auto bg-coal lg:hidden"
        >
          <div className="fine-grid absolute inset-0 opacity-40" aria-hidden="true" />
          <div className="absolute -right-24 top-1/4 h-80 w-80 rounded-full bg-gold/10 blur-[100px]" aria-hidden="true" />
          <div className="shell relative flex h-[4.5rem] shrink-0 items-center justify-between border-b border-cream/10">
            <Logo compact />
            <button
              ref={closeButtonRef}
              type="button"
              onClick={() => setMenuOpen(false)}
              aria-label="Закрыть меню"
              className="flex h-11 w-11 items-center justify-center border border-cream/20 text-cream transition-colors hover:border-gold hover:text-gold"
            >
              <CloseIcon />
            </button>
          </div>

          <nav aria-label="Мобильная навигация" className="shell relative flex flex-1 flex-col justify-center py-8">
            <ul>
              {navigation.map((item, index) => (
                <li key={item.id} className="border-b border-cream/10">
                  <a
                    href={item.href}
                    onClick={() => setMenuOpen(false)}
                    className="fade-up group flex min-h-[4rem] items-center justify-between gap-4 py-3"
                    style={{ animationDelay: `${80 + index * 45}ms` }}
                  >
                    <span className="flex items-baseline gap-4">
                      <span className="w-5 text-[10px] tabular-nums tracking-[0.14em] text-gold-deep">
                        0{index + 1}
                      </span>
                      <span className="text-[clamp(1.7rem,7vw,2.4rem)] font-light leading-tight tracking-[-0.02em] text-cream transition-colors group-hover:text-gold">
                        {item.label}
                      </span>
                    </span>
                    <ArrowUpRight className="h-5 w-5 text-cream/40 transition-transform duration-500 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-gold" />
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="shell relative shrink-0 border-t border-cream/10 py-6">
            <a
              href="#booking"
              onClick={() => setMenuOpen(false)}
              className={cn(btnGold, "w-full")}
            >
              Забронировать визит
              <ArrowUpRight className="arrow-shift" />
            </a>
            <div className="mt-5 flex items-center justify-between gap-4 text-[11px] uppercase tracking-[0.16em] text-sand">
              <span className="flex items-center gap-2">
                <MapPinIcon className="text-gold-deep" />
                Ставрополь
              </span>
              <a
                href="https://vionixclub.ru"
                target="_blank"
                rel="noopener noreferrer"
                className="underline-link text-cream/80"
              >
                vionixclub.ru
              </a>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
