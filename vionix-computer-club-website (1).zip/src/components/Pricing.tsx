import { useState } from "react";
import {
  durations,
  formatPrice,
  priceTable,
  type BookingZoneId,
  type DurationKey,
  type PriceKey,
} from "@/data/site";
import { cn } from "@/utils/cn";
import { ArrowUpRight, CheckIcon, InfoIcon, Reveal, SectionHead } from "@/components/ui";

const priceKeys: PriceKey[] = ["standard", "arena", "bootcamp", "duo"];

const bookingMap: Record<PriceKey, BookingZoneId> = {
  standard: "standard",
  arena: "arena",
  bootcamp: "bootcamp",
  duo: "duo27",
};

export function Pricing({
  onBook,
}: {
  onBook: (zone: BookingZoneId, duration?: DurationKey) => void;
}) {
  const [duration, setDuration] = useState<DurationKey>("3");
  const [selected, setSelected] = useState<PriceKey>("arena");
  const selectedRow = priceTable[selected];
  const selectedPrice = selectedRow.prices[duration];
  const selectedDuration = durations.find((item) => item.key === duration);

  return (
    <section id="pricing" className="bg-cream py-24 text-ink lg:py-32">
      <div className="shell">
        <Reveal>
          <SectionHead
            tone="light"
            index="03"
            kicker="Стоимость"
            title={
              <>
                Прозрачные цены.
                <br />
                <span className="italic-accent text-gold-deep">Без сюрпризов.</span>
              </>
            }
            description={
              <p>
                Игровое время продаётся блоками по 1, 3 и 5 часов. Выберите продолжительность и
                зону — стоимость сразу отобразится в сводке.
              </p>
            }
          />
        </Reveal>

        <div className="mt-12 grid gap-8 lg:mt-16 lg:grid-cols-12 lg:gap-10">
          <Reveal className="lg:col-span-8">
            <div
              role="group"
              aria-label="Выберите продолжительность игрового времени"
              className="inline-flex w-full border border-ink/15 bg-ink/[0.035] p-1 sm:w-auto"
            >
              {durations.map((item) => (
                <button
                  key={item.key}
                  type="button"
                  aria-pressed={duration === item.key}
                  onClick={() => setDuration(item.key)}
                  className={cn(
                    "min-h-11 flex-1 whitespace-nowrap px-4 text-[11px] font-semibold uppercase tracking-[0.12em] transition-colors duration-300 sm:flex-none sm:px-7",
                    duration === item.key
                      ? "bg-ink text-cream"
                      : "text-ink/60 hover:bg-ink/[0.05] hover:text-ink",
                  )}
                >
                  {item.short}
                </button>
              ))}
            </div>

            <div className="mt-6 hidden border-t border-ink/20 lg:block">
              <div className="grid grid-cols-[1.7fr_0.7fr_0.7fr_0.7fr_2.5rem] gap-4 border-b border-ink/15 px-4 py-4 text-[9px] uppercase tracking-[0.18em] text-ink/60">
                <span>Зона</span>
                {durations.map((item) => (
                  <span
                    key={item.key}
                    className={cn("text-center", duration === item.key && "text-ink")}
                  >
                    {item.short}
                  </span>
                ))}
                <span className="sr-only">Действие</span>
              </div>

              {priceKeys.map((key) => {
                const row = priceTable[key];
                const isSelected = selected === key;
                return (
                  <button
                    key={key}
                    type="button"
                    aria-pressed={isSelected}
                    onClick={() => setSelected(key)}
                    className={cn(
                      "group grid w-full grid-cols-[1.7fr_0.7fr_0.7fr_0.7fr_2.5rem] items-center gap-4 border-b border-ink/15 px-4 py-5 text-left transition-colors duration-300",
                      isSelected ? "bg-ink/[0.055]" : "hover:bg-ink/[0.035]",
                    )}
                  >
                    <span className="flex items-start gap-3">
                      <span
                        className={cn(
                          "mt-1 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border transition-colors",
                          isSelected
                            ? "border-ink bg-ink text-cream"
                            : "border-ink/25 text-transparent",
                        )}
                        aria-hidden="true"
                      >
                        <CheckIcon className="h-2.5 w-2.5" />
                      </span>
                      <span>
                        <span className="block text-[15px] font-semibold tracking-[0.05em]">
                          {row.name}
                        </span>
                        <span className="mt-1 block max-w-[16rem] text-[11px] leading-[1.5] text-ink/65">
                          {row.note}
                        </span>
                      </span>
                    </span>
                    {durations.map((item) => (
                      <span
                        key={item.key}
                        className={cn(
                          "text-center text-[15px] tabular-nums transition-colors",
                          duration === item.key
                            ? "font-semibold text-ink"
                            : "font-medium text-ink/70",
                        )}
                      >
                        {formatPrice(row.prices[item.key])} ₽
                      </span>
                    ))}
                    <span
                      className={cn(
                        "flex h-9 w-9 items-center justify-center justify-self-end border transition-all duration-300",
                        isSelected
                          ? "border-ink bg-ink text-cream"
                          : "border-ink/20 text-ink/50 group-hover:border-ink/50 group-hover:text-ink",
                      )}
                      aria-hidden="true"
                    >
                      <ArrowUpRight className="h-4 w-4" />
                    </span>
                  </button>
                );
              })}

              <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-4 text-[10px] uppercase tracking-[0.1em] text-ink/60">
                <span>Продолжительность</span>
                <span>1 час · 3 часа · 5 часов</span>
              </div>
            </div>

            <div className="mt-6 space-y-3 lg:hidden">
              {priceKeys.map((key) => {
                const row = priceTable[key];
                const isSelected = selected === key;
                return (
                  <button
                    key={key}
                    type="button"
                    aria-pressed={isSelected}
                    onClick={() => setSelected(key)}
                    className={cn(
                      "w-full border p-4 text-left transition-colors",
                      isSelected
                        ? "border-ink bg-ink/[0.055]"
                        : "border-ink/15 hover:border-ink/30",
                    )}
                  >
                    <span className="flex items-start justify-between gap-4">
                      <span>
                        <span className="block text-[15px] font-semibold tracking-[0.05em]">
                          {row.name}
                        </span>
                        <span className="mt-1 block text-[11px] leading-snug text-ink/65">
                          {row.note}
                        </span>
                      </span>
                      <span
                        className={cn(
                          "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border",
                          isSelected
                            ? "border-ink bg-ink text-cream"
                            : "border-ink/25 text-transparent",
                        )}
                        aria-hidden="true"
                      >
                        <CheckIcon className="h-2.5 w-2.5" />
                      </span>
                    </span>
                    <span className="mt-4 grid grid-cols-3 border-t border-ink/10 pt-3">
                      {durations.map((item, index) => (
                        <span
                          key={item.key}
                          className={cn(index > 0 && "border-l border-ink/10 pl-3")}
                        >
                          <span className="block text-[9px] uppercase tracking-[0.12em] text-ink/60">
                            {item.short}
                          </span>
                          <span
                            className={cn(
                              "mt-1 block text-[14px] tabular-nums",
                              duration === item.key
                                ? "font-semibold text-ink"
                                : "text-ink/70",
                            )}
                          >
                            {formatPrice(row.prices[item.key])} ₽
                          </span>
                        </span>
                      ))}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="mt-5 flex items-start gap-3 text-[11px] leading-[1.7] text-ink/65">
              <InfoIcon className="mt-0.5 shrink-0 text-gold-deep" />
              <p>
                Цены указаны за игровое место. Стоимость PlayStation 5 в исходных данных не
                опубликована — её подтверждает администратор клуба.
              </p>
            </div>
          </Reveal>

          <Reveal delay={120} className="lg:col-span-4">
            <div className="lg:sticky lg:top-28">
              <div className="bg-bark p-6 text-cream shadow-[0_24px_70px_rgba(23,21,19,0.18)] sm:p-8">
                <p className="text-[9px] uppercase tracking-[0.2em] text-sand">Ваш выбор</p>
                <div className="mt-5 flex items-baseline justify-between gap-4 border-b border-cream/10 pb-5">
                  <span className="text-[1.55rem] font-light tracking-[0.08em] text-cream">
                    {selectedRow.name}
                  </span>
                  <span className="border border-gold/25 px-2.5 py-1.5 text-[8px] uppercase tracking-[0.14em] text-gold">
                    {duration} ч
                  </span>
                </div>

                <div className="mt-5 flex items-end justify-between gap-4">
                  <div>
                    <p className="text-[10px] uppercase tracking-[0.16em] text-stone">
                      {selectedDuration?.label}
                    </p>
                    <p className="mt-2 text-[2.6rem] font-light leading-none tabular-nums text-cream">
                      {formatPrice(selectedPrice)} <span className="text-[1.4rem]">₽</span>
                    </p>
                  </div>
                  <span className="mb-1 text-[10px] uppercase tracking-[0.1em] text-sand">
                    ≈ {formatPrice(Math.round(selectedPrice / Number(duration)))} ₽ / час
                  </span>
                </div>

                <p className="mt-4 text-[11px] leading-[1.7] text-cream/55">{selectedRow.note}</p>

                <button
                  type="button"
                  onClick={() => onBook(bookingMap[selected], duration)}
                  className="mt-6 flex min-h-12 w-full items-center justify-between gap-4 bg-gold px-5 text-[10px] font-semibold uppercase tracking-[0.16em] text-ink transition-colors duration-300 hover:bg-cream"
                >
                  Забронировать {selected === "duo" ? "DUO 27'" : selectedRow.name}
                  <ArrowUpRight className="arrow-shift" />
                </button>

                <p className="mt-4 border-t border-cream/10 pt-4 text-[10px] leading-[1.7] text-cream/40">
                  Зона и время будут подставлены в форму бронирования. Финальное подтверждение —
                  у администратора.
                </p>
              </div>

              <div className="mt-3 grid grid-cols-2 gap-3">
                <div className="border border-ink/15 p-4">
                  <span className="text-[9px] uppercase tracking-[0.14em] text-ink/45">
                    Компьютеров
                  </span>
                  <p className="mt-2 text-[1.6rem] font-light leading-none">36</p>
                </div>
                <div className="border border-ink/15 p-4">
                  <span className="text-[9px] uppercase tracking-[0.14em] text-ink/45">
                    Форматов зон
                  </span>
                  <p className="mt-2 text-[1.6rem] font-light leading-none">5</p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
