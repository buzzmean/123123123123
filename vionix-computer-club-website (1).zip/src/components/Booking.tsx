import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  durations,
  formatPrice,
  getZonePrice,
  zoneOptions,
  type BookingZoneId,
  type DurationKey,
} from "@/data/site";
import { cn } from "@/utils/cn";
import {
  ArrowUpRight,
  btnGold,
  CopyIcon,
  CheckIcon,
  Dialog,
  fieldClass,
  InfoIcon,
  labelClass,
  Reveal,
} from "@/components/ui";

export interface BookingPreset {
  zone: BookingZoneId;
  duration: DurationKey;
  nonce: number;
}

interface FormValues {
  name: string;
  phone: string;
  zone: BookingZoneId | "";
  date: string;
  time: string;
  duration: DurationKey;
  consent: boolean;
}

interface BookingResult extends Omit<FormValues, "zone"> {
  zone: BookingZoneId;
  price: number | null;
}

type FieldName = keyof Omit<FormValues, "consent"> | "consent";
type FormErrors = Partial<Record<FieldName, string>>;

const emptyValues: FormValues = {
  name: "",
  phone: "",
  zone: "",
  date: "",
  time: "",
  duration: "1",
  consent: false,
};

function getTodayISO() {
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60_000);
  return local.toISOString().slice(0, 10);
}

function formatPhone(value: string) {
  const rawDigits = value.replace(/\D/g, "");
  if (rawDigits.length <= 1) return "";
  let digits = rawDigits;
  if (digits.startsWith("8")) digits = `7${digits.slice(1)}`;
  if (!digits.startsWith("7")) digits = `7${digits}`;
  digits = digits.slice(0, 11);
  const rest = digits.slice(1);
  let result = "+7";
  if (rest.length > 0) result += ` (${rest.slice(0, 3)}`;
  if (rest.length >= 3) result += `) ${rest.slice(3, 6)}`;
  if (rest.length >= 6) result += `-${rest.slice(6, 8)}`;
  if (rest.length >= 8) result += `-${rest.slice(8, 10)}`;
  return result;
}

function formatDate(value: string) {
  if (!value) return "—";
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(date);
}

function zoneLabel(zone: BookingZoneId | "") {
  if (!zone) return "Не выбрана";
  return zoneOptions.find((option) => option.value === zone)?.label.split(" — ")[0] ?? zone;
}

function ChevronDown() {
  return (
    <svg
      viewBox="0 0 16 10"
      aria-hidden="true"
      className="h-2.5 w-4 text-gold"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m1 1 7 7 7-7" />
    </svg>
  );
}

const steps = [
  {
    index: "01",
    title: "Выберите зону",
    text: "STANDARD, ARENA, BOOTCAMP, DUO или консольную PlayStation 5.",
  },
  {
    index: "02",
    title: "Укажите дату и время",
    text: "Заполните имя и телефон — маска подставит формат номера.",
  },
  {
    index: "03",
    title: "Проверьте заявку",
    text: "Сайт сформирует демо-заявку. Подтверждение — у администратора клуба.",
  },
];

export function Booking({ preset }: { preset: BookingPreset | null }) {
  const [values, setValues] = useState<FormValues>(emptyValues);
  const [errors, setErrors] = useState<FormErrors>({});
  const [result, setResult] = useState<BookingResult | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const copyTimer = useRef<number | null>(null);
  const today = useMemo(() => getTodayISO(), []);

  useEffect(() => {
    if (!preset) return;
    setValues((current) => ({
      ...current,
      zone: preset.zone,
      duration: preset.duration,
    }));
    setErrors((current) => ({ ...current, zone: undefined }));
  }, [preset]);

  useEffect(() => {
    return () => {
      if (copyTimer.current) window.clearTimeout(copyTimer.current);
    };
  }, []);

  const price = values.zone ? getZonePrice(values.zone, values.duration) : null;

  const updateField = <K extends keyof FormValues>(field: K, value: FormValues[K]) => {
    setValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
  };

  const validate = (): FormErrors => {
    const next: FormErrors = {};
    const trimmedName = values.name.trim();

    if (trimmedName.length < 2) {
      next.name = "Укажите имя — минимум 2 символа.";
    } else if (!/^[А-Яа-яЁёA-Za-z\s-]+$/.test(trimmedName)) {
      next.name = "В имени допустимы только буквы, пробел и дефис.";
    }

    if (values.phone.replace(/\D/g, "").length !== 11) {
      next.phone = "Введите телефон полностью: +7 (XXX) XXX-XX-XX.";
    }

    if (!values.zone) {
      next.zone = "Выберите игровую зону.";
    }

    if (!values.date) {
      next.date = "Укажите дату визита.";
    } else if (values.date < today) {
      next.date = "Дата не может быть в прошлом.";
    }

    if (!values.time) {
      next.time = "Укажите желаемое время.";
    }

    if (!values.consent) {
      next.consent = "Отметьте согласие, чтобы сформировать демо-заявку.";
    }

    return next;
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors = validate();
    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) {
      const firstField = Object.keys(nextErrors)[0];
      const element = document.getElementById(`booking-${firstField}`);
      element?.focus({ preventScroll: false });
      element?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    const zone = values.zone as BookingZoneId;
    setResult({
      ...values,
      zone,
      price: getZonePrice(zone, values.duration),
    });
    setCopied(false);
    setDialogOpen(true);
  };

  const resultText = result
    ? [
        "Черновик заявки VIONIX",
        "Форма демонстрационная — данные не отправлены в клуб.",
        `Имя: ${result.name.trim()}`,
        `Телефон: ${result.phone}`,
        `Зона: ${zoneLabel(result.zone)}`,
        `Дата: ${formatDate(result.date)}`,
        `Время: ${result.time}`,
        `Продолжительность: ${result.duration} ч.`,
        `Предварительная стоимость: ${result.price !== null ? `${formatPrice(result.price)} ₽` : "уточняется"}`,
      ].join("\n")
    : "";

  const copyResult = async () => {
    try {
      await navigator.clipboard.writeText(resultText);
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = resultText;
      textarea.setAttribute("readonly", "");
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
    }
    setCopied(true);
    if (copyTimer.current) window.clearTimeout(copyTimer.current);
    copyTimer.current = window.setTimeout(() => setCopied(false), 2600);
  };

  return (
    <section id="booking" className="relative overflow-hidden border-b border-cream/10 bg-ink py-24 lg:py-32">
      <div className="fine-grid absolute inset-0 opacity-[0.45]" aria-hidden="true" />
      <div
        className="absolute -left-32 top-1/4 h-[26rem] w-[26rem] rounded-full bg-gold/[0.06] blur-[120px]"
        aria-hidden="true"
      />
      <div className="shell relative">
        <div className="grid gap-10 lg:grid-cols-12 lg:gap-14">
          <Reveal className="lg:col-span-5">
            <p className="eyebrow">
              <span className="text-gold-deep">07</span>
              <span className="h-px w-6 bg-cream/25" aria-hidden="true" />
              Бронирование
            </p>
            <h2 className="display mt-6 text-[clamp(2.5rem,5vw,4.6rem)] text-cream">
              Ваше время
              <br />
              <span className="italic-accent text-gold">в клубе.</span>
            </h2>
            <p className="mt-6 max-w-md text-[14px] leading-[1.85] text-cream/65">
              Выберите зону и продолжительность — мы подставим стоимость в форму. Форма ниже демонстрационная: она проверит заполнение и покажет сводку, но не отправит данные в клуб.
            </p>

            <ol className="mt-9 space-y-0 border-t border-cream/10">
              {steps.map((step) => (
                <li key={step.index} className="flex gap-4 border-b border-cream/10 py-5 sm:gap-5">
                  <span className="w-6 shrink-0 pt-0.5 text-[10px] tabular-nums tracking-[0.14em] text-gold-deep">
                    {step.index}
                  </span>
                  <div>
                    <h3 className="text-[13px] font-medium tracking-[0.01em] text-cream">
                      {step.title}
                    </h3>
                    <p className="mt-1.5 max-w-sm text-[12px] leading-[1.75] text-sand">
                      {step.text}
                    </p>
                  </div>
                </li>
              ))}
            </ol>

            <div className="mt-6 border border-cream/15 bg-coal/55 p-5 backdrop-blur-sm">
              <div className="flex items-center justify-between gap-4">
                <span className="text-[9px] uppercase tracking-[0.18em] text-sand">
                  Предварительный расчёт
                </span>
                <span className="text-[9px] uppercase tracking-[0.14em] text-stone">
                  {values.duration} ч
                </span>
              </div>
              <div className="mt-4 flex items-end justify-between gap-4" aria-live="polite">
                <span className="text-[13px] leading-snug text-cream/70">
                  {zoneLabel(values.zone)}
                </span>
                <span className="whitespace-nowrap text-[1.6rem] font-light leading-none text-cream">
                  {price !== null ? `${formatPrice(price)} ₽` : "—"}
                </span>
              </div>
              <p className="mt-3 border-t border-cream/10 pt-3 text-[10px] leading-[1.7] text-stone">
                {values.zone === "ps5"
                  ? "Стоимость консольной зоны уточнит администратор клуба."
                  : "Расчёт не является подтверждением брони и не резервирует место."}
              </p>
            </div>
          </Reveal>

          <Reveal delay={120} className="lg:col-span-7">
            <div className="border border-cream/15 bg-bark/95 p-5 shadow-[0_30px_90px_rgba(0,0,0,0.28)] backdrop-blur-sm sm:p-8 lg:p-10">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-cream/10 pb-5">
                <div>
                  <h3 className="text-[15px] font-medium tracking-[0.02em] text-cream">
                    Параметры визита
                  </h3>
                  <p className="mt-1 text-[11px] text-stone">Все поля, отмеченные *, обязательны</p>
                </div>
                <span className="border border-gold/30 px-2.5 py-1.5 text-[8px] uppercase tracking-[0.16em] text-gold">
                  Демо-форма
                </span>
              </div>

              <form onSubmit={handleSubmit} noValidate className="mt-6">
                <div className="grid gap-5 sm:grid-cols-2">
                  <div>
                    <label htmlFor="booking-name" className={labelClass}>
                      Имя <span className="text-gold">*</span>
                    </label>
                    <input
                      id="booking-name"
                      name="name"
                      type="text"
                      autoComplete="name"
                      placeholder="Как к вам обращаться"
                      value={values.name}
                      onChange={(event) => updateField("name", event.target.value)}
                      aria-required="true"
                      aria-invalid={Boolean(errors.name)}
                      aria-describedby={errors.name ? "booking-name-error" : undefined}
                      className={cn(fieldClass, errors.name && "border-rose/70")}
                    />
                    {errors.name ? (
                      <p id="booking-name-error" className="mt-2 text-[11px] leading-snug text-rose">
                        {errors.name}
                      </p>
                    ) : null}
                  </div>

                  <div>
                    <label htmlFor="booking-phone" className={labelClass}>
                      Телефон <span className="text-gold">*</span>
                    </label>
                    <input
                      id="booking-phone"
                      name="phone"
                      type="tel"
                      inputMode="tel"
                      autoComplete="tel"
                      placeholder="+7 (___) ___-__-__"
                      value={values.phone}
                      onChange={(event) => updateField("phone", formatPhone(event.target.value))}
                      aria-required="true"
                      aria-invalid={Boolean(errors.phone)}
                      aria-describedby={errors.phone ? "booking-phone-error" : undefined}
                      className={cn(fieldClass, errors.phone && "border-rose/70")}
                    />
                    {errors.phone ? (
                      <p id="booking-phone-error" className="mt-2 text-[11px] leading-snug text-rose">
                        {errors.phone}
                      </p>
                    ) : null}
                  </div>

                  <div className="sm:col-span-2">
                    <label htmlFor="booking-zone" className={labelClass}>
                      Желаемая зона <span className="text-gold">*</span>
                    </label>
                    <div className="relative">
                      <select
                        id="booking-zone"
                        name="zone"
                        value={values.zone}
                        onChange={(event) =>
                          updateField("zone", event.target.value as BookingZoneId | "")
                        }
                        aria-required="true"
                        aria-invalid={Boolean(errors.zone)}
                        aria-describedby={errors.zone ? "booking-zone-error" : undefined}
                        className={cn(
                          fieldClass,
                          "appearance-none pr-12",
                          !values.zone && "text-cream/45",
                          errors.zone && "border-rose/70",
                        )}
                      >
                        <option value="">Выберите зону</option>
                        {zoneOptions.map((option) => (
                          <option key={option.value} value={option.value}>
                            {option.label}
                          </option>
                        ))}
                      </select>
                      <span className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2">
                        <ChevronDown />
                      </span>
                    </div>
                    {errors.zone ? (
                      <p id="booking-zone-error" className="mt-2 text-[11px] leading-snug text-rose">
                        {errors.zone}
                      </p>
                    ) : null}
                  </div>

                  <div>
                    <label htmlFor="booking-date" className={labelClass}>
                      Дата <span className="text-gold">*</span>
                    </label>
                    <input
                      id="booking-date"
                      name="date"
                      type="date"
                      min={today}
                      value={values.date}
                      onChange={(event) => updateField("date", event.target.value)}
                      aria-required="true"
                      aria-invalid={Boolean(errors.date)}
                      aria-describedby={errors.date ? "booking-date-error" : undefined}
                      className={cn(fieldClass, errors.date && "border-rose/70")}
                    />
                    {errors.date ? (
                      <p id="booking-date-error" className="mt-2 text-[11px] leading-snug text-rose">
                        {errors.date}
                      </p>
                    ) : null}
                  </div>

                  <div>
                    <label htmlFor="booking-time" className={labelClass}>
                      Время <span className="text-gold">*</span>
                    </label>
                    <input
                      id="booking-time"
                      name="time"
                      type="time"
                      step={900}
                      value={values.time}
                      onChange={(event) => updateField("time", event.target.value)}
                      aria-required="true"
                      aria-invalid={Boolean(errors.time)}
                      aria-describedby={errors.time ? "booking-time-error" : undefined}
                      className={cn(fieldClass, errors.time && "border-rose/70")}
                    />
                    {errors.time ? (
                      <p id="booking-time-error" className="mt-2 text-[11px] leading-snug text-rose">
                        {errors.time}
                      </p>
                    ) : null}
                  </div>
                </div>

                <fieldset className="mt-5">
                  <legend className={labelClass}>
                    Продолжительность <span className="text-gold">*</span>
                  </legend>
                  <div className="grid grid-cols-3 gap-2" id="booking-duration">
                    {durations.map((item) => (
                      <button
                        key={item.key}
                        type="button"
                        aria-pressed={values.duration === item.key}
                        onClick={() => updateField("duration", item.key)}
                        className={cn(
                          "min-h-12 border px-2 text-[11px] font-semibold uppercase tracking-[0.1em] transition-colors duration-300",
                          values.duration === item.key
                            ? "border-gold bg-gold text-ink"
                            : "border-cream/15 text-cream/65 hover:border-cream/35 hover:text-cream",
                        )}
                      >
                        {item.short}
                      </button>
                    ))}
                  </div>
                </fieldset>

                <div className="mt-5 border-t border-cream/10 pt-5">
                  <label
                    htmlFor="booking-consent"
                    className="flex cursor-pointer items-start gap-3 text-[11px] leading-[1.7] text-sand"
                  >
                    <input
                      id="booking-consent"
                      name="consent"
                      type="checkbox"
                      checked={values.consent}
                      onChange={(event) => updateField("consent", event.target.checked)}
                      aria-required="true"
                      aria-invalid={Boolean(errors.consent)}
                      aria-describedby={errors.consent ? "booking-consent-error" : undefined}
                      className="mt-0.5 h-4 w-4 shrink-0 accent-[#c9b18b]"
                    />
                    <span>
                      Согласен на обработку персональных данных в рамках демонстрационной
                      заявки. <span className="text-gold">*</span>
                    </span>
                  </label>
                  {errors.consent ? (
                    <p id="booking-consent-error" className="mt-2 pl-7 text-[11px] leading-snug text-rose">
                      {errors.consent}
                    </p>
                  ) : null}
                </div>

                <button type="submit" className={cn(btnGold, "mt-6 w-full justify-between px-5")}>
                  Сформировать демо-заявку
                  <ArrowUpRight className="arrow-shift" />
                </button>

                <div className="mt-4 flex items-start gap-3 border border-cream/10 p-4">
                  <InfoIcon className="mt-0.5 shrink-0 text-gold" />
                  <p className="text-[10px] leading-[1.75] text-stone">
                    Это демонстрационная форма. Она проверяет заполнение и показывает сводку, но
                    не отправляет данные в клуб и не бронирует место. Для реального бронирования
                    свяжитесь с администратором.
                  </p>
                </div>
              </form>
            </div>
          </Reveal>
        </div>
      </div>

      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        labelledBy="booking-result-title"
        dark
        className="max-w-2xl"
      >
        {result ? (
          <div className="p-6 sm:p-9">
            <span className="inline-flex items-center gap-2 border border-gold/35 px-3 py-1.5 text-[8px] uppercase tracking-[0.18em] text-gold">
              <span className="h-1 w-1 rounded-full bg-gold" aria-hidden="true" />
              Демонстрационный режим
            </span>
            <h2
              id="booking-result-title"
              className="display mt-5 text-[clamp(1.9rem,4vw,2.7rem)] text-cream"
            >
              Демо-заявка <span className="italic-accent text-gold">готова.</span>
            </h2>
            <p className="mt-3 max-w-lg text-[12px] leading-[1.8] text-sand">
              Данные заполнены корректно. Обратите внимание: заявка не отправлена в клуб и место
              не забронировано — форма работает в демонстрационном режиме.
            </p>

            <dl className="mt-6 border-t border-cream/15">
              {[
                { label: "Имя", value: result.name.trim() },
                { label: "Телефон", value: result.phone },
                { label: "Зона", value: zoneLabel(result.zone) },
                { label: "Дата", value: formatDate(result.date) },
                { label: "Время", value: result.time },
                { label: "Продолжительность", value: `${result.duration} ч.` },
                {
                  label: "Предварительная стоимость",
                  value: result.price !== null ? `${formatPrice(result.price)} ₽` : "Уточняется",
                },
              ].map((row) => (
                <div
                  key={row.label}
                  className="grid grid-cols-[1fr_1.4fr] gap-4 border-b border-cream/10 py-3 text-[12px]"
                >
                  <dt className="text-stone">{row.label}</dt>
                  <dd className="text-right font-medium text-cream">{row.value}</dd>
                </div>
              ))}
            </dl>

            <div className="mt-5 flex items-start gap-3 border border-gold/20 bg-gold/[0.045] p-4">
              <InfoIcon className="mt-0.5 shrink-0 text-gold" />
              <p className="text-[10px] leading-[1.75] text-sand">
                Чтобы забронировать место, свяжитесь с клубом напрямую. Контактные данные в
                разделе «Контакты» — редактируемые заглушки этой версии сайта.
              </p>
            </div>

            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <button
                type="button"
                onClick={copyResult}
                className="group inline-flex min-h-12 flex-1 items-center justify-between gap-4 bg-gold px-5 text-[10px] font-semibold uppercase tracking-[0.14em] text-ink transition-colors hover:bg-cream"
              >
                {copied ? "Скопировано" : "Скопировать данные"}
                {copied ? <CheckIcon /> : <CopyIcon />}
              </button>
              <button
                type="button"
                onClick={() => setDialogOpen(false)}
                className="inline-flex min-h-12 flex-1 items-center justify-center border border-cream/20 px-5 text-[10px] font-semibold uppercase tracking-[0.14em] text-cream transition-colors hover:border-gold hover:text-gold"
              >
                Вернуться к форме
              </button>
            </div>
            <p className="sr-only" role="status" aria-live="polite">
              {copied ? "Данные заявки скопированы в буфер обмена" : ""}
            </p>
          </div>
        ) : null}
      </Dialog>
    </section>
  );
}
