import { navigation } from "@/data/site";
import { ArrowRight, ArrowUpRight, Logo } from "@/components/ui";

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-ink">
      <div className="shell relative">
        <div className="grid gap-12 py-16 lg:grid-cols-12 lg:gap-8 lg:py-20">
          <div className="lg:col-span-5">
            <Logo />
            <p className="mt-6 max-w-sm text-[13px] leading-[1.85] text-cream/60">
              Премиальный компьютерный клуб в Ставрополе. 36 игровых компьютеров, пять форматов
              игровых зон, отдельная PlayStation 5-зона и пространства DUO.
            </p>
            <a
              href="https://vionixclub.ru"
              target="_blank"
              rel="noopener noreferrer"
              className="group mt-6 inline-flex min-h-11 items-center gap-3 text-[10px] uppercase tracking-[0.16em] text-gold transition-colors hover:text-cream"
            >
              Официальный сайт
              <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-500 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
          </div>

          <div className="lg:col-span-3">
            <h2 className="text-[9px] uppercase tracking-[0.2em] text-stone">Разделы</h2>
            <ul className="mt-5 grid gap-0.5">
              {navigation.map((item) => (
                <li key={item.id}>
                  <a
                    href={item.href}
                    className="group flex min-h-9 items-center justify-between gap-3 border-b border-cream/[0.07] text-[12px] text-cream/65 transition-colors hover:text-gold"
                  >
                    {item.label}
                    <ArrowRight className="arrow-line h-2.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-4">
            <h2 className="text-[9px] uppercase tracking-[0.2em] text-stone">Клуб</h2>
            <div className="mt-5 space-y-3 text-[12px] leading-relaxed text-cream/60">
              <p>
                <span className="block text-[9px] uppercase tracking-[0.14em] text-stone/70">
                  Город
                </span>
                Ставрополь, Россия
              </p>
              <p>
                <span className="block text-[9px] uppercase tracking-[0.14em] text-stone/70">
                  Адрес и телефон
                </span>
                Уточняются для публикации
              </p>
              <p>
                <span className="block text-[9px] uppercase tracking-[0.14em] text-stone/70">
                  Режим работы
                </span>
                Уточняется у администратора
              </p>
            </div>
            <a
              href="#booking"
              className="group mt-6 flex min-h-11 items-center justify-between gap-4 border border-cream/15 px-4 text-[9px] font-semibold uppercase tracking-[0.14em] text-cream/80 transition-colors hover:border-gold hover:text-gold"
            >
              Забронировать визит
              <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-500 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
          </div>
        </div>

        <div className="border-t border-cream/10 py-5">
          <p className="max-w-4xl text-[10px] leading-[1.8] text-stone">
            Демонстрационная версия сайта. Форма бронирования не отправляет данные и не
            резервирует место; контактные данные, режим работы и карта отмечены как заглушки.
            Изображения носят иллюстративный характер и не являются фотографиями клуба.
            Периферия указана по предоставленным данным.
          </p>
        </div>

        <div className="flex flex-col gap-4 border-t border-cream/10 py-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-[9px] uppercase tracking-[0.14em] text-stone">
            © {new Date().getFullYear()} VIONIX · Ставрополь
          </p>
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-[9px] uppercase tracking-[0.14em] text-stone">
            <span>Периферия · Logitech PRO / Red Square</span>
            <a href="#top" className="group flex min-h-9 items-center gap-2 transition-colors hover:text-gold">
              Наверх
              <span className="inline-block transition-transform duration-500 group-hover:-translate-y-1">
                <ArrowUpRight className="h-3 w-3" />
              </span>
            </a>
          </div>
        </div>
      </div>

      <div
        className="pointer-events-none select-none whitespace-nowrap px-[clamp(1rem,4.4vw,4.5rem)] pb-4 text-[clamp(4rem,14vw,13rem)] font-extralight leading-[0.78] tracking-[-0.05em] text-cream/[0.035]"
        aria-hidden="true"
      >
        VIONIX
      </div>
    </footer>
  );
}
