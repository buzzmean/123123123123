import { useRef, useState, type KeyboardEvent } from "react";
import { equipmentTabs } from "@/data/site";
import { cn } from "@/utils/cn";
import { ArrowUpRight, CheckIcon, InfoIcon, Reveal, SectionHead } from "@/components/ui";

export function Equipment() {
  const [activeIndex, setActiveIndex] = useState(0);
  const tabRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const active = equipmentTabs[activeIndex];

  const handleTabKeyDown = (event: KeyboardEvent<HTMLButtonElement>, index: number) => {
    if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
    event.preventDefault();
    const nextIndex =
      event.key === "ArrowRight"
        ? (index + 1) % equipmentTabs.length
        : (index - 1 + equipmentTabs.length) % equipmentTabs.length;
    setActiveIndex(nextIndex);
    tabRefs.current[nextIndex]?.focus();
  };

  return (
    <section id="equipment" className="border-y border-cream/10 bg-coal py-24 lg:py-32">
      <div className="shell">
        <Reveal>
          <SectionHead
            index="04"
            kicker="Оборудование"
            title={
              <>
                Периферия,
                <br />
                <span className="italic-accent text-gold">которой доверяют.</span>
              </>
            }
            description={
              <p>
                Состав периферии зависит от зоны. В разделах ниже — модели, которые указаны в
                конфигурации клуба VIONIX.
              </p>
            }
          />
        </Reveal>

        <Reveal className="mt-12 lg:mt-16">
          <div
            role="tablist"
            aria-label="Категории оборудования"
            className="tab-scroll -mx-5 flex overflow-x-auto border-b border-cream/15 px-5 sm:mx-0 sm:px-0"
          >
            {equipmentTabs.map((tab, index) => (
              <button
                key={tab.id}
                ref={(node) => {
                  tabRefs.current[index] = node;
                }}
                role="tab"
                id={`equipment-tab-${tab.id}`}
                aria-selected={activeIndex === index}
                aria-controls={`equipment-panel-${tab.id}`}
                tabIndex={activeIndex === index ? 0 : -1}
                onClick={() => setActiveIndex(index)}
                onKeyDown={(event) => handleTabKeyDown(event, index)}
                className={cn(
                  "relative min-h-12 shrink-0 whitespace-nowrap border-b px-4 text-[10px] font-semibold uppercase tracking-[0.14em] transition-colors duration-300 sm:px-6",
                  activeIndex === index
                    ? "border-gold text-cream"
                    : "border-transparent text-cream/40 hover:text-cream/75",
                )}
              >
                <span className="mr-2 text-[9px] tabular-nums text-gold-deep">0{index + 1}</span>
                {tab.label}
              </button>
            ))}
          </div>
        </Reveal>

        <div
          key={active.id}
          role="tabpanel"
          id={`equipment-panel-${active.id}`}
          aria-labelledby={`equipment-tab-${active.id}`}
          className="fade-up mt-6 grid gap-4 lg:mt-8 lg:grid-cols-12 lg:gap-5"
        >
          <div className="relative overflow-hidden bg-bark-2 lg:col-span-7">
            <img
              src={active.image}
              alt={active.imageAlt}
              loading="lazy"
              className="cine aspect-[4/3] h-full w-full object-cover sm:aspect-[16/10]"
            />
            <div
              className="absolute inset-0 bg-gradient-to-t from-ink/80 via-transparent to-ink/10"
              aria-hidden="true"
            />
            <div className="absolute inset-x-5 bottom-5 flex items-end justify-between gap-4 sm:inset-x-7 sm:bottom-7">
              <div>
                <span className="text-[9px] uppercase tracking-[0.2em] text-gold">
                  {active.label}
                </span>
                <p className="mt-2 text-[1.5rem] font-light leading-tight text-cream sm:text-[1.9rem]">
                  {active.title}
                </p>
              </div>
              <span className="hidden border border-cream/20 bg-coal/40 px-3 py-1.5 text-[9px] uppercase tracking-[0.16em] text-cream/70 backdrop-blur-md sm:block">
                Gear / {String(activeIndex + 1).padStart(2, "0")}
              </span>
            </div>
          </div>

          <div className="flex flex-col border border-cream/10 bg-bark p-6 sm:p-8 lg:col-span-5 lg:p-9">
            <div className="flex items-center justify-between gap-4 border-b border-cream/10 pb-4">
              <span className="text-[9px] uppercase tracking-[0.2em] text-sand">
                Конфигурация
              </span>
              <span className="text-[9px] uppercase tracking-[0.14em] text-stone">
                {active.items.length} {active.items.length === 1 ? "позиция" : "позиции"}
              </span>
            </div>

            <ul className="flex-1">
              {active.items.map((item, index) => (
                <li
                  key={item.name}
                  className="group flex items-center justify-between gap-4 border-b border-cream/10 py-5"
                >
                  <div className="flex min-w-0 items-start gap-4">
                    <span className="mt-1 w-5 shrink-0 text-[9px] tabular-nums tracking-[0.12em] text-gold-deep">
                      0{index + 1}
                    </span>
                    <div className="min-w-0">
                      <span className="block text-[9px] uppercase tracking-[0.16em] text-stone">
                        {item.type}
                      </span>
                      <span className="mt-1.5 block text-[15px] font-medium leading-snug text-cream transition-colors group-hover:text-gold sm:text-[16px]">
                        {item.name}
                      </span>
                    </div>
                  </div>
                  <CheckIcon className="shrink-0 text-gold/60" />
                </li>
              ))}
            </ul>

            <div className="mt-5">
              {active.missingNote ? (
                <div className="flex items-start gap-3 border border-gold/20 bg-gold/[0.045] p-4">
                  <InfoIcon className="mt-0.5 shrink-0 text-gold" />
                  <p className="text-[11px] leading-[1.7] text-sand">{active.missingNote}</p>
                </div>
              ) : (
                <div className="flex items-start gap-3 border border-cream/10 p-4">
                  <InfoIcon className="mt-0.5 shrink-0 text-gold" />
                  <p className="text-[11px] leading-[1.7] text-sand">
                    Комплект указан по данным клуба. Полную конфигурацию конкретного места
                    подтверждает администратор.
                  </p>
                </div>
              )}

              <a
                href="#booking"
                className="group mt-4 flex min-h-12 items-center justify-between gap-4 border border-cream/20 px-5 text-[10px] font-semibold uppercase tracking-[0.16em] text-cream transition-colors duration-300 hover:border-gold hover:text-gold"
              >
                Проверить зону в бронировании
                <ArrowUpRight className="arrow-shift" />
              </a>
            </div>
          </div>
        </div>

        <Reveal>
          <p className="mt-5 max-w-3xl text-[10px] leading-[1.7] text-stone">
            Изображения оборудования носят иллюстративный характер и не являются официальными
            фотографиями перечисленных моделей. Актуальный состав периферии на выбранном месте
            уточняйте у администратора клуба.
          </p>
        </Reveal>
      </div>

      <div className="shell mt-16 hidden lg:block">
        <Reveal>
          <div className="grid grid-cols-3 gap-5 border-t border-cream/10 pt-8">
            {[
              { label: "Игровые места", value: "36" },
              { label: "Периферия PRO", value: "Logitech" },
              { label: "Консольная зона", value: "PlayStation 5" },
            ].map((item) => (
              <div
                key={item.label}
                className="group flex items-center justify-between gap-4 border border-cream/10 px-6 py-5 transition-colors hover:border-gold/30"
              >
                <span className="text-[10px] uppercase tracking-[0.16em] text-stone">
                  {item.label}
                </span>
                <span className="text-[13px] font-medium tracking-[0.04em] text-cream group-hover:text-gold">
                  {item.value}
                </span>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
