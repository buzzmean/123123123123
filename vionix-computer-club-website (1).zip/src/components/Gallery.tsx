import { useEffect, useState } from "react";
import { gallery } from "@/data/site";
import {
  ArrowLeft,
  ArrowRight,
  Dialog,
  PlusIcon,
  Reveal,
  SectionHead,
} from "@/components/ui";

export function Gallery() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const open = activeIndex !== null;
  const active = activeIndex !== null ? gallery[activeIndex] : null;

  const close = () => setActiveIndex(null);
  const goNext = () =>
    setActiveIndex((current) => (current === null ? null : (current + 1) % gallery.length));
  const goPrev = () =>
    setActiveIndex((current) =>
      current === null ? null : (current - 1 + gallery.length) % gallery.length,
    );

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "ArrowRight") goNext();
      if (event.key === "ArrowLeft") goPrev();
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [open]);

  return (
    <section id="gallery" className="border-b border-cream/10 bg-bark py-24 lg:py-32">
      <div className="shell">
        <Reveal>
          <SectionHead
            index="05"
            kicker="Галерея"
            title={
              <>
                Свет, посадка
                <br />
                <span className="italic-accent text-gold">и детали.</span>
              </>
            }
            description={
              <>
                <p>
                  Подборка кадров, передающих настроение премиального игрового пространства.
                  Нажмите на изображение, чтобы рассмотреть детали.
                </p>
                <span className="mt-5 inline-flex items-center gap-2 border border-gold/25 px-3 py-2 text-[9px] uppercase tracking-[0.14em] text-gold">
                  <span className="h-1 w-1 rounded-full bg-gold" aria-hidden="true" />
                  Визуальные референсы
                </span>
              </>
            }
          />
        </Reveal>

        <div className="mt-12 columns-1 gap-4 sm:columns-2 lg:mt-16 lg:columns-3 lg:gap-5">
          {gallery.map((item, index) => (
            <Reveal
              key={`${item.title}-${item.subtitle}`}
              delay={(index % 3) * 80}
              className="mb-4 break-inside-avoid lg:mb-5"
            >
              <button
                type="button"
                onClick={() => setActiveIndex(index)}
                aria-label={`Открыть изображение: ${item.title}`}
                className="group relative block w-full overflow-hidden bg-bark-2 text-left"
              >
                <img
                  src={item.src}
                  alt={item.alt}
                  loading={index < 3 ? "eager" : "lazy"}
                  className={`cine w-full object-cover transition-transform duration-[1.5s] ease-out group-hover:scale-[1.04] ${item.aspect}`}
                />
                <span
                  className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/5 to-transparent opacity-70 transition-opacity duration-500 group-hover:opacity-100"
                  aria-hidden="true"
                />
                <span className="absolute inset-x-4 bottom-4 flex items-end justify-between gap-4">
                  <span>
                    <span className="block text-[9px] uppercase tracking-[0.18em] text-gold">
                      {item.subtitle}
                    </span>
                    <span className="mt-1.5 block text-[15px] font-medium text-cream sm:text-[17px]">
                      {item.title}
                    </span>
                  </span>
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center border border-cream/25 bg-coal/35 text-cream backdrop-blur-md transition-all duration-500 group-hover:border-gold group-hover:bg-gold group-hover:text-ink">
                    <PlusIcon className="h-4 w-4" />
                  </span>
                </span>
              </button>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <div className="mt-4 flex flex-col gap-3 border-t border-cream/10 pt-5 text-[10px] leading-[1.7] text-stone sm:flex-row sm:items-center sm:justify-between">
            <p>
              Фотографии носят иллюстративный характер и не являются снимками клуба VIONIX.
              Реальная фотосъёмка будет добавлена перед публикацией.
            </p>
            <a
              href="https://www.pexels.com"
              target="_blank"
              rel="noopener noreferrer"
              className="underline-link shrink-0 text-cream/60 transition-colors hover:text-gold"
            >
              Фотографии: Pexels
            </a>
          </div>
        </Reveal>
      </div>

      <Dialog
        open={open}
        onClose={close}
        labelledBy="lightbox-title"
        dark
        className="max-w-6xl"
      >
        {active ? (
          <div>
            <div className="flex items-center justify-center bg-ink px-4 py-6 sm:px-14 sm:py-10">
              <img
                key={active.src}
                src={active.src}
                alt={active.alt}
                className="fade-up max-h-[60svh] w-auto max-w-full object-contain"
              />
            </div>
            <div className="flex flex-col gap-5 p-5 pr-16 sm:flex-row sm:items-center sm:justify-between sm:p-6 sm:pr-20">
              <div>
                <span className="text-[9px] uppercase tracking-[0.18em] text-gold">
                  {active.subtitle}
                </span>
                <h2 id="lightbox-title" className="mt-1.5 text-[1.2rem] font-light text-cream">
                  {active.title}
                </h2>
                <p className="mt-1 text-[10px] text-stone">
                  Иллюстративное изображение · {String((activeIndex ?? 0) + 1).padStart(2, "0")} /{" "}
                  {String(gallery.length).padStart(2, "0")}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={goPrev}
                  aria-label="Предыдущее изображение"
                  className="flex h-11 w-11 items-center justify-center border border-cream/20 text-cream transition-colors hover:border-gold hover:text-gold"
                >
                  <ArrowLeft />
                </button>
                <button
                  type="button"
                  onClick={goNext}
                  aria-label="Следующее изображение"
                  className="flex h-11 w-11 items-center justify-center border border-cream/20 text-cream transition-colors hover:border-gold hover:text-gold"
                >
                  <ArrowRight />
                </button>
              </div>
            </div>
          </div>
        ) : null}
      </Dialog>
    </section>
  );
}
