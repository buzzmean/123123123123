import {
  formatPrice,
  getZonePrice,
  priceTable,
  zones,
  type BookingZoneId,
  type DurationKey,
  type Zone,
} from "@/data/site";
import { cn } from "@/utils/cn";
import {
  ArrowRight,
  ArrowUpRight,
  btnGold,
  btnOutline,
  Reveal,
  SectionHead,
} from "@/components/ui";

const cardGrid: Record<Zone["layout"], string> = {
  featured: "lg:col-span-12",
  standard: "lg:col-span-5",
  wide: "lg:col-span-7",
  compact: "lg:col-span-6",
};

function ZoneCard({
  zone,
  onBook,
}: {
  zone: Zone;
  onBook: (zone: BookingZoneId, duration?: DurationKey) => void;
}) {
  const featured = zone.layout === "featured";
  const priceKey = zone.priceKey;
  const prices = priceKey ? priceTable[priceKey].prices : null;
  const fromPrice = getZonePrice(zone.id, "1");

  return (
    <article
      className={cn(
        "group relative flex h-full flex-col border border-cream/10 bg-coal transition-colors duration-500 hover:border-gold/40",
        cardGrid[zone.layout],
        featured && "lg:grid lg:grid-cols-12",
      )}
    >
      <div
        className={cn(
          "relative overflow-hidden bg-bark-2",
          featured ? "aspect-[16/10] lg:order-2 lg:col-span-6 lg:aspect-auto lg:min-h-[34rem]" : "",
          zone.layout === "standard" && "aspect-[4/3]",
          zone.layout === "wide" && "aspect-[16/10]",
          zone.layout === "compact" && "aspect-[16/10] lg:aspect-[16/9]",
        )}
      >
        <img
          src={zone.image}
          alt={zone.imageAlt}
          loading="lazy"
          className="cine absolute inset-0 h-full w-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-[1.045]"
        />
        <div
          className="absolute inset-0 bg-gradient-to-t from-ink/75 via-ink/10 to-ink/10"
          aria-hidden="true"
        />
        <span className="absolute left-4 top-4 flex h-8 min-w-8 items-center justify-center border border-cream/25 bg-coal/55 px-2 text-[10px] tracking-[0.16em] text-cream backdrop-blur-md">
          {zone.index}
        </span>
        <div className="absolute inset-x-4 bottom-4 flex items-end justify-between gap-4">
          <span className="text-[9px] uppercase tracking-[0.18em] text-cream/60">
            {zone.subtitle}
          </span>
          {fromPrice ? (
            <span className="border border-cream/20 bg-coal/50 px-3 py-1.5 text-[10px] uppercase tracking-[0.12em] text-cream backdrop-blur-md">
              от {formatPrice(fromPrice)} ₽ / час
            </span>
          ) : null}
        </div>
      </div>

      <div
        className={cn(
          "flex flex-1 flex-col p-5 sm:p-7",
          featured && "lg:col-span-6 lg:justify-center lg:p-10 xl:p-14",
        )}
      >
        <div className="flex items-start justify-between gap-6">
          <div>
            <h3
              className={cn(
                "font-light leading-none tracking-[0.06em] text-cream",
                featured ? "text-[2.1rem] xl:text-[2.8rem]" : "text-[1.65rem] sm:text-[1.9rem]",
              )}
            >
              {zone.name}
            </h3>
            <p className="mt-2 text-[12px] leading-relaxed text-sand">{zone.subtitle}</p>
          </div>
          {featured ? (
            <span className="mt-1 hidden shrink-0 border border-gold/30 px-3 py-1.5 text-[9px] uppercase tracking-[0.16em] text-gold sm:block">
              Logitech PRO
            </span>
          ) : null}
        </div>

        <p
          className={cn(
            "mt-5 text-[13px] leading-[1.8] text-cream/65",
            featured ? "max-w-md lg:text-[14px]" : "max-w-md",
          )}
        >
          {zone.description}
        </p>

        <ul
          className={cn(
            "mt-6 flex flex-wrap gap-x-5 gap-y-2.5 border-t border-cream/10 pt-5",
            featured && "lg:grid lg:grid-cols-1 lg:gap-2.5",
          )}
        >
          {zone.specs.map((spec) => (
            <li
              key={spec}
              className="flex items-start gap-2 text-[11px] leading-[1.6] tracking-[0.02em] text-sand"
            >
              <span
                className="mt-[0.45rem] h-1 w-1 shrink-0 rotate-45 bg-gold/80"
                aria-hidden="true"
              />
              {spec}
            </li>
          ))}
        </ul>

        <div className={cn("mt-auto pt-7", featured && "lg:pt-9")}>
          <div className="grid grid-cols-3 border-y border-cream/10">
            {(["1", "3", "5"] as DurationKey[]).map((duration, index) => (
              <button
                key={duration}
                type="button"
                onClick={() => onBook(zone.id, duration)}
                aria-label={`Выбрать ${zone.name} на ${duration} ч.`}
                className={cn(
                  "group/price min-h-[3.65rem] px-1 py-3 text-left transition-colors duration-300 hover:bg-gold/[0.06]",
                  index > 0 && "border-l border-cream/10 pl-4",
                )}
              >
                <span className="block text-[9px] uppercase tracking-[0.16em] text-stone">
                  {duration} ч
                </span>
                <span className="mt-1 block text-[14px] font-light text-cream transition-colors group-hover/price:text-gold sm:text-[16px]">
                  {prices ? `${formatPrice(prices[duration])} ₽` : "Уточняется"}
                </span>
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => onBook(zone.id, "1")}
            className={cn(
              featured ? btnGold : btnOutline,
              "mt-4 w-full justify-between gap-4 px-5",
            )}
          >
            Забронировать
            <ArrowUpRight className="arrow-shift" />
          </button>
        </div>
      </div>
    </article>
  );
}

export function Zones({
  onBook,
}: {
  onBook: (zone: BookingZoneId, duration?: DurationKey) => void;
}) {
  return (
    <section id="zones" className="border-y border-cream/10 bg-bark py-24 lg:py-32">
      <div className="shell">
        <Reveal>
          <SectionHead
            index="02"
            kicker="Игровые зоны"
            title={
              <>
                Пять форматов.
                <br />
                <span className="italic-accent text-gold">Один уровень.</span>
              </>
            }
            description={
              <>
                <p>
                  Каждая зона — самостоятельный формат посадки. Выберите тот, который подходит
                  вашему сценарию: одному, вдвоём или командой.
                </p>
                <a
                  href="#pricing"
                  className="group mt-5 inline-flex min-h-10 items-center gap-3 text-[10px] uppercase tracking-[0.18em] text-gold transition-colors hover:text-cream"
                >
                  Смотреть полный прайс
                  <ArrowRight className="arrow-line" />
                </a>
              </>
            }
          />
        </Reveal>

        <div className="mt-12 grid gap-4 sm:mt-16 lg:grid-cols-12 lg:gap-5">
          {zones.map((zone, index) => (
            <Reveal key={zone.id} delay={(index % 3) * 90} className={cardGrid[zone.layout]}>
              <ZoneCard zone={zone} onBook={onBook} />
            </Reveal>
          ))}
        </div>

        <Reveal>
          <div className="mt-6 flex flex-col gap-2 border-t border-cream/10 pt-5 text-[11px] leading-relaxed text-stone sm:flex-row sm:items-baseline sm:justify-between sm:gap-8">
            <p>Стоимость указана за игровое место для одной персоны.</p>
            <p className="max-w-xl sm:text-right">
              Точная конфигурация зоны и доступность на выбранное время уточняются при
              бронировании.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
