import heroImage from "@/assets/images/hero.jpg";
import zoneStandardImage from "@/assets/images/zone-standard.jpg";
import zoneArenaImage from "@/assets/images/zone-arena.jpg";
import zoneBootcampImage from "@/assets/images/zone-bootcamp.jpg";
import zoneDuo27Image from "@/assets/images/zone-duo27.jpg";
import zoneDuo24Image from "@/assets/images/zone-duo24.jpg";
import loungeImage from "@/assets/images/lounge.jpg";
import gamerImage from "@/assets/images/gamer.jpg";
import galleryOneImage from "@/assets/images/gallery-1.jpg";
import galleryTwoImage from "@/assets/images/gallery-2.jpg";
import galleryThreeImage from "@/assets/images/gallery-3.jpg";
import galleryFourImage from "@/assets/images/gallery-4.jpg";
import gearKeyboardImage from "@/assets/images/gear-keyboard.jpg";
import gearHeadsetImage from "@/assets/images/gear-headset.jpg";
import ps5Image from "@/assets/images/ps5.jpg";

export const images = {
  hero: heroImage,
  lounge: loungeImage,
  gamer: gamerImage,
  ps5: ps5Image,
  gearKeyboard: gearKeyboardImage,
  gearHeadset: gearHeadsetImage,
};

export type DurationKey = "1" | "3" | "5";

export type PriceKey = "standard" | "arena" | "bootcamp" | "duo";

export type BookingZoneId = PriceKey | "duo27" | "duo24" | "ps5";

export const durations: { key: DurationKey; short: string; label: string }[] = [
  { key: "1", short: "1 час", label: "1 час игрового времени" },
  { key: "3", short: "3 часа", label: "3 часа игрового времени" },
  { key: "5", short: "5 часов", label: "5 часов игрового времени" },
];

export const priceTable: Record<
  PriceKey,
  { name: string; note: string; prices: Record<DurationKey, number> }
> = {
  standard: {
    name: "STANDARD",
    note: "Игровое место для одного",
    prices: { "1": 180, "3": 430, "5": 680 },
  },
  arena: {
    name: "ARENA",
    note: "Отдельная игровая категория",
    prices: { "1": 230, "3": 550, "5": 850 },
  },
  bootcamp: {
    name: "BOOTCAMP",
    note: "Зона с клавиатурой Red Square ALUMIX",
    prices: { "1": 270, "3": 650, "5": 1050 },
  },
  duo: {
    name: "DUO",
    note: "DUO 27' и DUO 24' — отдельные пространства",
    prices: { "1": 350, "3": 900, "5": 1350 },
  },
};

export interface Zone {
  id: BookingZoneId;
  priceKey: PriceKey | null;
  index: string;
  name: string;
  subtitle: string;
  description: string;
  specs: string[];
  equipment: string[];
  image: string;
  imageAlt: string;
  layout: "featured" | "standard" | "wide" | "compact";
}

export const zones: Zone[] = [
  {
    id: "arena",
    priceKey: "arena",
    index: "02",
    name: "ARENA",
    subtitle: "Для игры всерьёз",
    description:
      "Отдельная игровая категория с полной конфигурацией Logitech PRO. Здесь продумано всё, что находится вокруг игрока, — чтобы внимание оставалось только в игре.",
    specs: ["Игровой компьютер", "Периферия Logitech PRO", "Категория ARENA"],
    equipment: [
      "Клавиатура Logitech PRO X2 RAPID",
      "Мышь Logitech PRO X2 SUPERSTRIKE",
      "Наушники Logitech PRO X3 LIGHTSPEED",
    ],
    image: zoneArenaImage,
    imageAlt: "Игровые компьютеры и кресла в тёмном пространстве клуба",
    layout: "featured",
  },
  {
    id: "standard",
    priceKey: "standard",
    index: "01",
    name: "STANDARD",
    subtitle: "Точка входа в VIONIX",
    description:
      "Собранное игровое место с полной PRO-периферией. Всё необходимое для игры — без лишнего.",
    specs: ["Игровой компьютер", "Периферия Logitech PRO", "Категория STANDARD"],
    equipment: [
      "Клавиатура Logitech PRO X2 RAPID",
      "Мышь Logitech PRO X2 SUPERSTRIKE",
      "Наушники Logitech PRO X3 LIGHTSPEED",
    ],
    image: zoneStandardImage,
    imageAlt: "Рабочее место геймера с монитором и подсветкой в тёмной комнате",
    layout: "standard",
  },
  {
    id: "bootcamp",
    priceKey: "bootcamp",
    index: "03",
    name: "BOOTCAMP",
    subtitle: "Для тренировок и команды",
    description:
      "Категория с клавиатурой Red Square ALUMIX. Формат, в котором удобно собраться командой или отработать свою игру.",
    specs: ["Клавиатура Red Square ALUMIX", "Игровой компьютер", "Категория BOOTCAMP"],
    equipment: ["Клавиатура Red Square ALUMIX"],
    image: zoneBootcampImage,
    imageAlt: "Команда игроков за компьютерами в игровом пространстве",
    layout: "wide",
  },
  {
    id: "duo27",
    priceKey: "duo",
    index: "04",
    name: "DUO 27'",
    subtitle: "Два места. Одно пространство",
    description:
      "Отдельное пространство DUO для игры вдвоём. Можно прийти с другом и не делить внимание с соседними игроками.",
    specs: ["Отдельное пространство", "Формат DUO 27'", "Мышь Logitech PRO X2 SUPERSTRIKE"],
    equipment: ["Мышь Logitech PRO X2 SUPERSTRIKE"],
    image: zoneDuo27Image,
    imageAlt: "Стол с игровым компьютером и креслом у тёмной кирпичной стены",
    layout: "compact",
  },
  {
    id: "duo24",
    priceKey: "duo",
    index: "05",
    name: "DUO 24'",
    subtitle: "Компактный формат для двоих",
    description:
      "Отдельная зона на двоих с собственной посадкой. Подходит для спокойной игры вдвоём или небольшой компании.",
    specs: ["Отдельное пространство", "Формат DUO 24'", "Периферия Logitech PRO"],
    equipment: [
      "Клавиатура Logitech PRO X2 RAPID",
      "Мышь Logitech PRO X2 SUPERSTRIKE",
      "Наушники Logitech PRO X3 LIGHTSPEED",
    ],
    image: zoneDuo24Image,
    imageAlt: "Современная игровая станция с двумя мониторами и подсветкой",
    layout: "compact",
  },
];

export const equipmentTabs: {
  id: string;
  label: string;
  title: string;
  image: string;
  imageAlt: string;
  items: { type: string; name: string }[];
  missingNote?: string;
}[] = [
  {
    id: "pro",
    label: "STANDARD / ARENA",
    title: "Полный комплект PRO",
    image: gearKeyboardImage,
    imageAlt: "Игровая клавиатура с подсветкой и мышь крупным планом",
    items: [
      { type: "Клавиатура", name: "Logitech PRO X2 RAPID" },
      { type: "Мышь", name: "Logitech PRO X2 SUPERSTRIKE" },
      { type: "Наушники", name: "Logitech PRO X3 LIGHTSPEED" },
    ],
  },
  {
    id: "bootcamp",
    label: "BOOTCAMP",
    title: "Red Square ALUMIX",
    image: galleryThreeImage,
    imageAlt: "Игровая клавиатура, наушники и мышь на рабочем столе",
    items: [{ type: "Клавиатура", name: "Red Square ALUMIX" }],
    missingNote:
      "Остальная периферия для BOOTCAMP в исходных данных не указана. Полную конфигурацию уточните у администратора клуба.",
  },
  {
    id: "duo27",
    label: "DUO 27'",
    title: "Точная настройка",
    image: gearHeadsetImage,
    imageAlt: "Игровые мышь, клавиатура и наушники в тёмном свете",
    items: [{ type: "Мышь", name: "Logitech PRO X2 SUPERSTRIKE" }],
    missingNote:
      "Остальная периферия для DUO 27' в исходных данных не указана. Полную конфигурацию уточните у администратора клуба.",
  },
  {
    id: "duo24",
    label: "DUO 24'",
    title: "Полный комплект",
    image: heroImage,
    imageAlt: "Игровое место с монитором и периферией в тёмном интерьере",
    items: [
      { type: "Клавиатура", name: "Logitech PRO X2 RAPID" },
      { type: "Мышь", name: "Logitech PRO X2 SUPERSTRIKE" },
      { type: "Наушники", name: "Logitech PRO X3 LIGHTSPEED" },
    ],
  },
];

export const gallery = [
  {
    src: galleryOneImage,
    alt: "Игровой зал с компьютерами и приглушённым светом",
    title: "Игровой зал",
    subtitle: "Периметр и посадка",
    aspect: "aspect-[4/3]",
  },
  {
    src: loungeImage,
    alt: "Современная лаунж-зона с мягким тёплым освещением",
    title: "Лаунж",
    subtitle: "Пауза между сессиями",
    aspect: "aspect-[3/4]",
  },
  {
    src: galleryTwoImage,
    alt: "Игроки за компьютерными экранами во время матча",
    title: "Командная игра",
    subtitle: "Вместе или один на один",
    aspect: "aspect-square",
  },
  {
    src: zoneArenaImage,
    alt: "Ряды игровых мест с креслами и подсветкой",
    title: "ARENA",
    subtitle: "Игровые категории",
    aspect: "aspect-[4/5]",
  },
  {
    src: galleryThreeImage,
    alt: "Крупный план игровой периферии на столе",
    title: "Периферия",
    subtitle: "Logitech PRO",
    aspect: "aspect-[4/3]",
  },
  {
    src: ps5Image,
    alt: "Контроллер PlayStation 5 на консоли",
    title: "PlayStation 5",
    subtitle: "Отдельная зона",
    aspect: "aspect-[4/3]",
  },
  {
    src: gamerImage,
    alt: "Игрок в наушниках за компьютером в клубе",
    title: "Атмосфера",
    subtitle: "Внимание к деталям",
    aspect: "aspect-[3/4]",
  },
  {
    src: galleryFourImage,
    alt: "Два контроллера на тёмной деревянной поверхности",
    title: "Детали",
    subtitle: "Всё под рукой",
    aspect: "aspect-[16/10]",
  },
];

export const navigation = [
  { href: "#zones", label: "Зоны", id: "zones" },
  { href: "#pricing", label: "Цены", id: "pricing" },
  { href: "#equipment", label: "Оборудование", id: "equipment" },
  { href: "#gallery", label: "Галерея", id: "gallery" },
  { href: "#ps5", label: "PS5", id: "ps5" },
  { href: "#contacts", label: "Контакты", id: "contacts" },
];

export function getZonePrice(zone: BookingZoneId, duration: DurationKey): number | null {
  const priceKey: PriceKey | null =
    zone === "duo27" || zone === "duo24" ? "duo" : zone === "ps5" ? null : zone;
  if (!priceKey) return null;
  return priceTable[priceKey].prices[duration];
}

export function formatPrice(value: number): string {
  return new Intl.NumberFormat("ru-RU").format(value);
}

export const zoneOptions: { value: BookingZoneId; label: string }[] = [
  { value: "standard", label: "STANDARD — 180 / 430 / 680 ₽" },
  { value: "arena", label: "ARENA — 230 / 550 / 850 ₽" },
  { value: "bootcamp", label: "BOOTCAMP — 270 / 650 / 1050 ₽" },
  { value: "duo27", label: "DUO 27' — 350 / 900 / 1350 ₽" },
  { value: "duo24", label: "DUO 24' — 350 / 900 / 1350 ₽" },
  { value: "ps5", label: "PlayStation 5 — стоимость уточняется" },
];

export const contactPlaceholders = {
  address: "Адрес клуба — уточняется",
  phone: "Телефон — будет опубликован",
  hours: "Режим работы — уточняется",
  social: "Социальные сети — будут добавлены",
  officialSite: "vionixclub.ru",
};
